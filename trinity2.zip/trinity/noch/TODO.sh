#!/bin/sh

grep -r TODO ./*.c ./*.h
