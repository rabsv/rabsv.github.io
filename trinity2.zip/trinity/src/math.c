#include "math.h"

static bool is_point_between_line_points(float x, float y, line_t line) {
	if (line.x1 > line.x2)
		SWAP(line.x1, line.x2, float);
	if (x > line.x2 || x < line.x1)
		return false;

	if (line.y1 > line.y2)
		SWAP(line.y1, line.y2, float);
	if (y > line.y2 || y < line.y1)
		return false;

	return true;
}

bool line_intersect(line_t a, line_t b, float *ix, float *iy) {
	float m1 = (a.y2 - a.y1) / (a.x2 - a.x1);
	float c1 = a.y1 - m1 * a.x1;

	float m2 = (b.y2 - b.y1) / (b.x2 - b.x1);
	float c2 = b.y1 - m2 * b.x1;

	if (m1 - m2 == 0)
		return false;

	*ix = (c2 - c1) / (m1 - m2);
	*iy = m1 * *ix + c1;

	return is_point_between_line_points(*ix, *iy, a) && is_point_between_line_points(*ix, *iy, b);
}

void fix_dir(float *dir) {
	while (*dir >= M_PI * 2) *dir -= M_PI * 2;
	while (*dir < 0)         *dir += M_PI * 2;
}
