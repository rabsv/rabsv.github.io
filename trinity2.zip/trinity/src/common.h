#ifndef COMMON_H_HEADER_GUARD
#define COMMON_H_HEADER_GUARD

#include <stdlib.h> /* malloc, realloc, free */
#include <string.h> /* memset */
#include <assert.h> /* assert */

#include <noch/log.h>
#include <noch/common.h>

#define NEW(TYPE) (TYPE*)zalloc(sizeof(TYPE))

void *xalloc  (size_t bytes);
void *zalloc  (size_t bytes);
void *xrealloc(void *ptr, size_t bytes);
void  xfree   (void *ptr);

#endif
