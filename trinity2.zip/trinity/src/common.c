#include "common.h"

void *xalloc(size_t bytes) {
	assert(bytes > 0);

	void *ptr = malloc(bytes);
	if (ptr == NULL)
		LOG_FATAL("Memory allocation failed");

	return ptr;
}

void *zalloc(size_t bytes) {
	void *ptr = xalloc(bytes);
	memset(ptr, 0, bytes);
	return ptr;
}

void *xrealloc(void *ptr, size_t bytes) {
	assert(ptr != NULL);
	assert(bytes > 0);

	ptr = realloc(ptr, bytes);
	if (ptr == NULL)
		LOG_FATAL("Memory reallocation failed");

	return ptr;
}

void xfree(void *ptr) {
	assert(ptr != NULL);

	free(ptr);
}
