#ifndef EDITOR_H_HEADER_GUARD
#define EDITOR_H_HEADER_GUARD

#include <SDL2/SDL.h>
#include <noch/log.h>

#include "config.h"
#include "common.h"
#include "math.h"
#include "video.h"
#include "gfx.h"
#include "engine.h"

typedef struct {
	SDL_Event      evt;
	const uint8_t *keys;

	world_t  world;
	scene_t  scene;
	camera_t cam;

	/* Temporary */
	font_t *font, *fontbold;

	size_t tick, fps_timer, fps;
	bool   quit, paused, mouse_look;
} game_t;

game_t *game_new(const char *path, float scale, bool antialias, bool fullscr);
void    game_destroy(game_t *this);

void game_update(game_t *this);
void game_render(game_t *this);

#endif
