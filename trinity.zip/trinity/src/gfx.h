#ifndef GFX_H_HEADER_GUARD
#define GFX_H_HEADER_GUARD

#include <stdio.h>  /* FILE, fopen, fclose, fgetc */
#include <stdint.h> /* uint32_t, uint8_t */

#include <SDL2/SDL.h>

#include "common.h"
#include "math.h"

inline uint32_t rgb_to_abgr32(int r, int g, int b) {
	return r | (g << 8) | (b << 16) | 0xFF000000;
}

inline void abgr32_to_rgb(uint32_t abgr32, int *r, int *g, int *b) {
	*r =  abgr32 & 0x0000FF;
	*g = (abgr32 & 0x00FF00) >> 8;
	*b = (abgr32 & 0xFF0000) >> 16;
}

#define COLORS      256
#define SHADES      64
#define PALS_CAP    8
#define TRANSPARENT 255
#define BLACK       0
#define WHITE       254

typedef struct {
	uint8_t  *colormap;
	uint32_t *pal, *pals[PALS_CAP];
} colorinfo_t;

extern colorinfo_t colorinfo;

void colorinfo_clean(void);

void load_palette_bmp(int id, const char *path);
void use_palette(int id);

void load_colormap_lmp(const char *path);

uint8_t color_shade(uint8_t color, float shade);
uint8_t color_find_closest_to_rgb(int r, int g, int b);

typedef struct {
	uint8_t *buf;
	int      w, h, size;

	int x1, y1, x2, y2;
} canvas_t;

canvas_t *canvas_new     (int w, int h);
void      canvas_destroy (canvas_t *this);
void      canvas_resize  (canvas_t *this, int w, int h);
canvas_t *canvas_load_lmp(const char *path);
void      canvas_save_lmp(canvas_t *this, const char *path);

void canvas_viewport(canvas_t *this, rect_t *rect);

void canvas_fill (canvas_t *this, uint8_t color);
void canvas_clear(canvas_t *this);

uint8_t *canvas_at(canvas_t *this, int x, int y);

void canvas_rect_fill   (canvas_t *this, rect_t *rect, uint8_t color);
void canvas_rect_outline(canvas_t *this, rect_t *rect, uint8_t color);
void canvas_rect_canvas (canvas_t *this, rect_t *rect, canvas_t *canvas, rect_t *src);
void canvas_rect_dither (canvas_t *this, rect_t *rect, uint8_t color);
void canvas_line        (canvas_t *this, int x1, int y1, int x2, int y2, int n, uint8_t color);

typedef struct {
	canvas_t *sheet;
	int ch_w, ch_h, row_len;
} font_t;

font_t *font_load_lmp(const char *path, int ch_w, int ch_h);
void    font_destroy(font_t *this);

int font_render(font_t *this, const char *str, canvas_t *canvas,
                int start_x, int start_y, float scale, uint8_t color);

#endif
