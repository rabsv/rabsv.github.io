#ifndef MATH_HH_HEADER_GUARD
#define MATH_HH_HEADER_GUARD

#include <stdbool.h> /* bool, true, false */
#include <math.h>
#include <stdlib.h> /* fabs */

#include <noch/common.h>

#ifndef M_PI
#	define M_PI 3.14159265358979323846
#endif

#ifndef M_SQRT2
#	define M_SQRT2 1.4142135623731
#endif

#define DTOR(DEG) ((float)(DEG) * M_PI / 180)
#define RTOD(RAD) ((float)(RAD) * 180 / M_PI)

#define MAX(A, B) (A > B? A : B)
#define MIN(A, B) (A < B? A : B)

typedef struct {
	float x1, y1, x2, y2;
} line_t;

inline line_t line_new(float x1, float y1, float x2, float y2) {
	return (line_t){.x1 = x1, .y1 = y1, .x2 = x2, .y2 = y2};
}

bool line_intersect(line_t a, line_t b, float *ix, float *iy);

typedef struct {
	int x, y, w, h;
} rect_t;

inline rect_t rect_new(int x, int y, int w, int h) {
	return (rect_t){.x = x, .y = y, .w = w, .h = h};
}

inline bool rect_contains(rect_t *rect, int x, int y) {
	return x >= rect->x && x < (rect->x + rect->w) && y >= rect->y && y < (rect->y + rect->h);
}

inline float dist(float x1, float y1, float x2, float y2) {
	return hypot(fabs(x2 - x1), fabs(y2 - y1));
}

inline float lerp(float a, float b, float f) {
	/* Slower, but more precise lerp:
	 * return a * (1.0 - f) + b * f;
	 */

	return a + f * (b - a);
}

void fix_dir(float *dir);

#endif
