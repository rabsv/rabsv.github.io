#include "engine.h"

uint8_t tile_get_point_split_side(tile_t *tile, float x, float y) {
	if (tile->split == SPLIT_HORZ)
		return y > (tile->p1 + (tile->p2 - tile->p1) * x);
	else if (tile->split == SPLIT_VERT)
		return x > (tile->p1 + (tile->p2 - tile->p1) * y);
	else
		return 0;
}

line_t tile_get_angled_wall_line(tile_t *tile) {
	line_t line;

	if (tile->split == SPLIT_HORZ) {
		line.x1 = 0;
		line.y1 = tile->p1;

		line.x2 = 1;
		line.y2 = tile->p2;
	} else if (tile->split == SPLIT_VERT) {
		line.x1 = tile->p1;
		line.y1 = 0;

		line.x2 = tile->p2;
		line.y2 = 1;
	} else
		ZERO_STRUCT(&line);

	return line;
}

entity_t *entity_new(float x, float y, float z, float w, float h, float zh,
                     float d, float max_speed, uint8_t sprite_id) {
	entity_t *this = NEW(entity_t);
	this->x = x;
	this->y = y;
	this->z = z;

	this->w  = w;
	this->h  = h;
	this->zh = zh;

	this->d  = d;
	this->zd = 0;

	this->max_speed = max_speed;
	this->sprite_id = sprite_id;
	return this;
}

void entity_destroy(entity_t *this) {
	xfree(this);
}

void entity_accel(entity_t *this, float amount, float d) {
	this->vx += cos(d) * amount;
	this->vx += cos(d) * amount;

	float speed = hypot(this->vx, this->vy);
	if (speed > this->max_speed) {
		this->vx *= this->max_speed / speed;
		this->vy *= this->max_speed / speed;
	}
}

void entity_accel_forw(entity_t *this, float amount) {
	entity_accel(this, amount, this->d);
}

void entity_update(entity_t *this, float friction) {
	this->x += this->vx;
	this->y += this->vy;

	this->vx *= friction;
	this->vy *= friction;
}

static void world_hardcoded(world_t *this) {
	this->w    = 30;
	this->h    = 28;
	this->size = this->w * this->h;

	/* Set both to -1 to disable */
	//this->fog_end   = 20;
	this->fog_end   = 30;
	this->fog_start = -5;
	this->fog_len   = this->fog_end - this->fog_start;

	this->shadow      = 0.2;
	this->shadow_vert = false;

	this->sky_floor_id = 4;
	this->sky_floor_h  = -0.5;

	const char *map = "wwwwwwwwwwwwwwww,,,,wwwwwwwwww"
	                  "wwwwwwwwwwwwwww,,!!,,wwwwwwwww"
	                  "wwwwwwwwwwwwwww,!!,,wwwwwwwwww"
	                  "wwwwwwwwwwwwwwww,,wwwwwwwwwwww"
	                  "wwwwwwwwwwwwwwwwwwwwwwwwwwwwww"
	                  "wwwww#wwwwwwwwwwwwwwwT''#wwwww"
	                  "wwwww#wwT''Twwwwww   '''#wwwww"
	                  "wwwwwVww''''!,,,,,   '''Vwwwww"
	                  "wwwww#ww''''!!,,,,   '''#wwwww"
	                  "wwwww#wwT''T!!,,,,   T''#wwwww"
	                  "wwwwwVwww--!!,,,,,    --#wwwww"
	                  "wwww,#www__!,,,,,,    __#wwwww"
	                  "wwww,#www..,,,,,,,    ..#wwwww"
	                  "www,,Vww    ,,,,,,      #wwwww"
	                  "www,,#ww    ,,ss,,      Vwwwww"
	                  "www,!#ww                Vwwwww"
	                  "ww,,!Vww                #wwwww"
	                  "ww,!!#ww          .T'''Twwwwww"
	                  "ww,!##ww          _'''''wwwwww"
	                  "ww,,#FWW#WW#AAA#  -'''''wwwwww"
	                  "www,#FWWWWBAAAAA  a''$''wwwwww"
	                  "wwwwUWWWWWBAAAAA  aT'''Twwwwww"
	                  "wwwwUWWFF##########wwwwwwwwwww"
	                  "wwwwUUU###!!!,,,,wwwwwwwwwwwww"
	                  "wwwwwww,,!!,,,wwwwwwwwwwwwwwww"
	                  "wwwwwwww,,,wwwwwwwwwwwwwwwwwww"
	                  "wwwwwwwwwwwwwwwwwwwwwwwwwwwwww"
	                  "wwwwwwwwwwwwwwwwwwwwwwwwwwwwww";

	assert((int)strlen(map) == this->size);

	this->tiles = (tile_t*)xalloc(this->size * sizeof(tile_t));

	float plr_x = -1, plr_y = -1, plr_z = -1;
	for (int i = 0; i < this->size; ++ i) {
		tile_t *tile = this->tiles + i;
		ZERO_STRUCT(tile);
		tile->friction = 0.88;

		*tile->floor_h = 0;
		*tile->ceil_h  = 3.5;
		*tile->ceil_id = -1;

		for (int i = 0; i < 5; ++ i) {
			tile->wall_id[i]  = 3;
			tile->wall_off[i] = 0.25;
		}

		switch (map[i]) {
		case '#':
			*tile->type = WALL;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 7;
			break;

		case 'V':
			*tile->type = FLOOR;
			*tile->floor_id = 2;
			*tile->floor_h  = 1.8;
			*tile->ceil_id  = 2;
			*tile->ceil_h   = 2.5;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 7;
			break;

		case 'T':
			*tile->type = WALL;
			break;

		case 'w':
			*tile->type     = FLOOR;
			*tile->floor_id = -1;
			*tile->floor_h  = -0.5;
			break;

		case 'W':
			*tile->type     = FLOOR;
			*tile->floor_id = -1;
			*tile->ceil_id  = 2;
			*tile->ceil_h   = 2;
			*tile->floor_h  = -0.5;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 7;
			break;

		case 'F':
			*tile->type     = FLOOR;
			*tile->ceil_id  = 2;
			*tile->ceil_h   = 2;
			*tile->floor_id = 1;
			break;

		case 'U':
			*tile->type     = FLOOR;
			*tile->floor_id = -1;
			*tile->ceil_id  = 2;
			*tile->ceil_h   = 0.3;
			*tile->floor_h  = -0.5;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 7;
			break;

		case 'A':
			*tile->type     = FLOOR;
			*tile->floor_id = -1;
			*tile->ceil_id  = 2;
			*tile->ceil_h   = 2;
			*tile->floor_h  = -1;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 7;
			break;

		case 'B':
			*tile->type     = FLOOR;
			*tile->floor_id = -1;
			*tile->ceil_id  = 2;
			*tile->ceil_h   = 2;
			*tile->floor_h  = -0.5;
			tile->wall_id[SIDE_LEFT] = 5;
			tile->wall_id[SIDE_DOWN]    = 7;
			break;

		case ',':
			*tile->type     = FLOOR;
			*tile->floor_id = 6;
			*tile->floor_h  = -0.4;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 6;
			break;

		case '!':
			*tile->type     = FLOOR;
			*tile->floor_id = 6;
			*tile->floor_h  = -0.2;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i] = 6;
			break;

		case 'C':
			*tile->type    = FLOOR;
			*tile->ceil_id = 2;
			*tile->ceil_h  = 1.5;
			for (int i = 0; i < 5; ++ i)
				tile->wall_id[i]  = 7;
			break;

		case '$':
			plr_x = 0.5 + i % this->w;
			plr_y = 0.5 + i / this->w;
			plr_z = 1.2 + 0.5;
			/* Fallthrough */

		case '\'':
			*tile->floor_h = 1.2;
			*tile->ceil_h  = 2.8;
			*tile->ceil_id = 1;
			break;

		case 'a':
			*tile->floor_h = 1.2;
			break;

		case '-':
			*tile->floor_h = 0.9;
			break;

		case '_':
			*tile->floor_h = 0.6;
			break;

		case '.':
			*tile->floor_h = 0.3;
			break;

		case ' ':
			*tile->floor_id = 1;
			break;

		case 's':
			*tile->floor_id = 1;
			*tile->floor_h = -0.2;
			break;

		default: LOG_FATAL("Unknown map tile '%c'", map[i]);
		}
	}

	assert(plr_x != -1 && plr_y != -1);
	this->plr = entity_new(plr_x, plr_y, plr_z, 0.1, 0.1, 0.5, 0, 0.06, -1);

	this->entities_count = 1;
	this->entities[0]    = this->plr;
}

void world_init(world_t *this, const char *sheet_path, int tile_size, const char *sky_path) {
	this->sheet.canv = canvas_load_lmp(sheet_path);
	this->sky        = canvas_load_lmp(sky_path);

	this->sheet.tile_size = tile_size;
	this->sheet.id_count  = this->sheet.canv->size / this->sheet.tile_size / this->sheet.tile_size;
	this->sheet.row_len   = this->sheet.canv->w / this->sheet.tile_size;

	this->anims = (anim_t*)xalloc(this->sheet.id_count * sizeof(anim_t));
	for (int i = 0; i < this->sheet.id_count; ++ i) {
		this->anims[i].ticks   = 0;
		this->anims[i].next_id = i;
	}

	this->sheet.id_data_map = xalloc(this->sheet.id_count * sizeof(*this->sheet.id_data_map));
	for (int i = 0; i < this->sheet.id_count; ++ i) {
		this->sheet.id_data_map[i].x = i % this->sheet.row_len * this->sheet.tile_size;
		this->sheet.id_data_map[i].y = i / this->sheet.row_len * this->sheet.tile_size;

		/* TODO: Temporary */
		this->sheet.id_data_map[i].waves = i == 4 || i == 5;
	}

	world_hardcoded(this);
}

void world_deinit(world_t *this) {
	for (int i = 0; i < this->entities_count; ++ i)
		entity_destroy(this->entities[i]);

	canvas_destroy(this->sheet.canv);
	canvas_destroy(this->sky);

	xfree(this->anims);
	xfree(this->tiles);
	xfree(this->sheet.id_data_map);
}

static void animate(anim_t *anims, uint8_t *id, size_t tick) {
	if (*id == SKY)
		return;

	anim_t *anim = anims + *id;
	if (anim->ticks == 0)
		return;

	if (tick > 0 && tick % anim->ticks == 0)
		*id = anim->next_id;
}

void world_update(world_t *this, size_t tick) {
	for (int i = 0; i < this->size; ++ i) {
		tile_t *tile = this->tiles + i;

		for (int i = 0; i < 2; ++ i) {
			animate(this->anims, tile->floor_id + i, tick);
			animate(this->anims, tile->ceil_id  + i, tick);
		}

		for (int i = 0; i < 5; ++ i)
			animate(this->anims, tile->wall_id + i, tick);
	}
}

void world_put_point_in_bounds(world_t *this, float *x, float *y, bool offset) {
	float off = offset? 0.05 : 0;

	if (*x > (float)this->w - off) *x = (float)this->w - off;
	if (*y > (float)this->h - off) *y = (float)this->h - off;

	if (*x < off) *x = off;
	if (*y < off) *y = off;
}

bool world_contains(world_t *this, float x, float y) {
	return x >= 0 && x < this->w && y >= 0 && y < this->h;
}

void scene_setup(scene_t *this, world_t *world, canvas_t *canv, float fov) {
	ZERO_STRUCT(this);
	this->world        = world;
	this->canv         = canv;
	this->fov          = fov;
	this->wave_off_map = (int*)xalloc(this->world->sheet.tile_size * sizeof(int));
	this->fall_off_map = (int*)xalloc(this->world->sheet.tile_size * sizeof(int));

	scene_resized(this);
}

void scene_cleanup(scene_t *this) {
	xfree(this->x_to_d_map);
	xfree(this->wave_off_map);
	xfree(this->fall_off_map);
}

static void scene_create_x_to_d_map(scene_t *this) {
	if (this->x_to_d_map != NULL)
		xfree(this->x_to_d_map);

	/* TODO: FOV is not affected by the window size, so when you stretch the window width the
	 *       screen stretches too and looks silly. For example in quake, the FOV simply expands
	 *       which eliminates stretching. Fix this.
	 */

	this->x_to_d_map = xalloc(this->canv->w * sizeof(float));
	this->plane_dist        = this->center_x / tan(DTOR(this->fov / 2));
	for (int x = 0; x < this->canv->w; ++ x)
		this->x_to_d_map[x] = atan2((float)x - this->center_x, this->plane_dist);
}

void scene_resized(scene_t *this) {
	this->center_x = (float)this->canv->w / 2;
	this->center_y = (float)this->canv->h / 2;

	scene_create_x_to_d_map(this);
}

void scene_set_fov(scene_t *this, float fov) {
	this->fov = fov;
	scene_create_x_to_d_map(this);
}

void scene_set_camera(scene_t *this, camera_t cam) {
	this->cam     = cam;
	this->cam_off = this->cam.zd / M_PI * 2 * this->canv->h;
}

static tile_t tile_out_of_bounds = {
	.split   = SPLIT_NONE,
	.type    = {WALL},
	.wall_id = {SKY, SKY, SKY, SKY, SKY},
};

static void sector_end_block(sector_t *sect, ray_t *ray, tile_t *tile) {
	sect->dist   = ray->dist;
	sect->tile_x = ray->x;
	sect->tile_y = ray->y;
	sect->tile   = tile;

	if (ray->horz) {
		int off = ray->dx < 0? 1 : 0;

		sect->x    = sect->tile_x + off;
		sect->y    = ray->start_y + ray->dy * ray->dist;
		sect->side = SIDE_RIGHT + off;
	} else {
		int off = ray->dy < 0? 1 : 0;

		sect->x    = ray->start_x + ray->dx * ray->dist;
		sect->y    = sect->tile_y + off;
		sect->side = SIDE_DOWN + off;
	}
}

static void sector_end_angled(sector_t *sect, ray_t *ray, tile_t *tile, float ix, float iy) {
	ZERO_STRUCT(sect);
	sect->dist   = ray->dist;
	sect->tile_x = ray->x;
	sect->tile_y = ray->y;
	sect->tile   = tile;
	sect->x      = (float)ray->x + ix;
	sect->y      = (float)ray->y + iy;
	sect->dist   = dist(ray->start_x, ray->start_y, sect->x, sect->y);
	sect->mid    = true;

	if (ray->horz)
		sect->side = SIDE_RIGHT + (ray->dx < 0? 1 : 0);
	else
		sect->side = SIDE_DOWN + (ray->dy < 0? 1 : 0);
}

static void sector_end_fog(sector_t *sect, ray_t *ray, float fog_dist) {
	ZERO_STRUCT(sect);
	sect->tile_x = ray->x;
	sect->tile_y = ray->y;
	sect->dist   = fog_dist;
	sect->fog    = true;
	sect->x      = ray->start_x + ray->dx * sect->dist;
	sect->y      = ray->start_y + ray->dy * sect->dist;
}

static bool scene_ray_hit_bounds(scene_t *this, ray_t *ray, sector_t *sect) {
	if (!world_contains(this->world, ray->x, ray->y)) {
		sector_end_block(sect, ray, &tile_out_of_bounds);
		return true;
	}

	return false;
}

static bool scene_ray_hit_fog(scene_t *this, ray_t *ray, sector_t *sect) {
	if (this->end_at_fog && ray->dist >= this->world->fog_end) {
		sector_end_fog(sect, ray, this->world->fog_end);
		return true;
	}

	return false;
}

static bool scene_ray_hit_wall(scene_t *this, ray_t *ray, sector_t *sect) {
	tile_t *tile = WORLD_AT(this->world, ray->x, ray->y);
	bool floor = tile->floor_h[0] != this->prev_floor_h; // TODO: Angled walls: || tile->floor_h[1] != this->prev_floor_h;
	bool ceil  = tile->ceil_h[0]  != this->prev_ceil_h;  // TODO: Angled walls: || tile->ceil_h[1]  != this->prev_ceil_h;
	bool wall  = tile->type[0]    != FLOOR;              // TODO: Angled walls: || tile->type[1]    != FLOOR;

	this->prev_floor_h = *tile->floor_h;
	this->prev_ceil_h  = *tile->ceil_h;

	if (!wall)
		ray_enable_collision(ray);

	if (floor || ceil || wall) {
		/* A solid block tile */
		if (tile->split == SPLIT_NONE) {
			if (ray->can_collide) {
				sector_end_block(sect, ray, tile);
				return true;
			} else
				return false;
		}

		/* TODO: Angled walls with different floor height */

		line_t a = tile_get_angled_wall_line(tile);
		line_t b = ray_get_line_in_tile(ray);

		uint8_t split_side;
		UNUSED(split_side);
		if (!ray->stepped) {
			/* Which split side is the player on? */
			split_side = tile_get_point_split_side(tile, b.x1, b.y1);

			/* If the player is in a split side with a wall, we wont render the angled wall */
			if (tile->type[split_side] == WALL) {
				if (tile->type[tile_get_point_split_side(tile, b.x2, b.y2)] == FLOOR) {
					ray_enable_collision(ray);
					return false;
				} else
					return false;
			}
		} else {
			/* Which split side is the ray touching? */
			if (tile->split == SPLIT_HORZ)
				split_side = ray->horz? b.y1 > (ray->dx < 0? tile->p2 : tile->p1) : ray->dy < 0;
			else if (tile->split == SPLIT_VERT)
				split_side = ray->horz? ray->dx < 0 :  b.x1 > (ray->dy < 0? tile->p2 : tile->p1);
			else
				UNREACHABLE(); /* C warns about uninitialized values without this */

			/* If the ray is touching a wall side, we wont render the angled wall */
			if (tile->type[split_side] == WALL) {
				if (ray->can_collide) {
					sector_end_block(sect, ray, tile);
					return true;
				} else
					return false;
			}
		}

		float ix, iy;
		if (line_intersect(a, b, &ix, &iy)) {
			ray_enable_collision(ray);

			sect->split_side = split_side;
			sector_end_angled(sect, ray, tile, ix, iy);
			return true;
		} else if (!ray->stepped)
			ray_enable_collision(ray);

		return false;
	} /*else if (tile->type[0] == FLOOR && tile->type[1] == FLOOR)
		ray_enable_collision(ray);*/

	return false;
}

static bool scene_ray_hit_sector_end(scene_t *this, ray_t *ray, sector_t *sect) {
	if (scene_ray_hit_bounds(this, ray, sect))
		return true;
	else if (scene_ray_hit_fog(this, ray, sect))
		return true;
	else if (scene_ray_hit_wall(this, ray, sect))
		return true;
	else
		return false;
}

static int scene_raycast(scene_t *this, sector_t *sects) {
	int   count = 0;
	ray_t ray;
	ray_init(&ray, this->cam.x, this->cam.y, this->dx, this->dy);

	tile_t *tile    = WORLD_AT(this->world, ray.x, ray.y);
	float   floor_h = *tile->floor_h; /* TODO: Angled walls support */
	float   ceil_h  = *tile->ceil_h;
	// TODO: terrible wave code
	bool    wave    = *tile->floor_id == (uint8_t)-1? SHEET_ID_HAS_WAVES(&this->world->sheet, this->world->sky_floor_id) : SHEET_ID_HAS_WAVES(&this->world->sheet, *tile->floor_id);
	int     wave_id = *tile->floor_id == (uint8_t)-1? this->world->sky_floor_id : (int8_t)*tile->floor_id;

	this->prev_floor_h = floor_h;
	this->prev_ceil_h  = ceil_h;
	while (true) {
		sector_t sect = {0};
		if (scene_ray_hit_sector_end(this, &ray, &sect)) {
			sect.floor_h = floor_h;
			sect.ceil_h  = ceil_h;
			sect.h       = ceil_h - floor_h;
			sect.wave    = wave;
			sect.wave_id = wave_id;

			floor_h = *sect.tile->floor_h;
			ceil_h  = *sect.tile->ceil_h;
			wave    = *sect.tile->floor_id == (uint8_t)-1? SHEET_ID_HAS_WAVES(&this->world->sheet, this->world->sky_floor_id) : SHEET_ID_HAS_WAVES(&this->world->sheet, *sect.tile->floor_id);
			wave_id = *sect.tile->floor_id == (uint8_t)-1? this->world->sky_floor_id : (int8_t)*sect.tile->floor_id;

			assert(count < SECTORS_CAP);
			sects[count ++] = sect;

			if (*sect.tile->type == WALL)
				break;
		}

		ray_step(&ray);
	}

	return count;
}

static void tex_pos_fix(int *pos, int tile_size) {
	while (*pos >= tile_size)
		*pos -= tile_size;
	while (*pos < 0)
		*pos += tile_size;
}

static float scene_calc_fog(scene_t *this, float dist) {
	if (dist >= this->world->fog_start) {
		float fog = (dist - this->world->fog_start) / this->world->fog_len;

		if      (fog > 1) fog = 1;
		else if (fog < 0) fog = 0;

		return fog;
	} else
		return 0;
}

static int scene_calc_wave(scene_t *this, float off) {
	return this->wave_off_map[(int)(off * this->world->sheet.tile_size)];
}

static int scene_calc_fall(scene_t *this, float off) {
	return this->fall_off_map[(int)(off * this->world->sheet.tile_size)];
}

enum {
	SURFACE_FLOOR = 0,
	SURFACE_CEIL,
};

static void scene_get_surface_tex_pos(scene_t *this, uint8_t id, float norm_x, float norm_y,
                                      int *tex_x, int *tex_y) {
	*tex_x = norm_x * this->world->sheet.tile_size;
	*tex_y = norm_y * this->world->sheet.tile_size;

	if (SHEET_ID_HAS_WAVES(&this->world->sheet, id)) {
		*tex_x += scene_calc_wave(this, norm_y);
		*tex_y += scene_calc_wave(this, norm_x);
	}

	tex_pos_fix(tex_y, this->world->sheet.tile_size);
	tex_pos_fix(tex_x, this->world->sheet.tile_size);

	*tex_x += SHEET_ID_TO_X(&this->world->sheet, id);
	*tex_y += SHEET_ID_TO_Y(&this->world->sheet, id);
}

static void scene_render_sky_ceil_pixel(scene_t *this, column_t *col, int y) {
	/* TODO: Fix horizontal distortion of the sky perspective */
	float h = this->center_y + 1;

	float off_y = (h - h * col->d_fix) * ((h - y) / h) - (this->cam_off * col->d_fix);

	//float tex_x = (float)col->x / this->canv->w * this->world->sky->w;
	float tex_y = ((float)y + off_y) / h * this->world->sky->h / 2 + this->world->sky->h / 2;

	if (tex_y < 0)                    tex_y = 0;
	if (tex_y >= this->world->sky->h) tex_y = this->world->sky->h - 1;

	//tex_x += this->cam.d / (M_PI / 2) * this->world->sky->w;
	float tex_x = (this->cam.d + this->x_to_d_map[col->x]) / (M_PI * 2) * this->world->sky->w;

	while (tex_x >= this->world->sky->w) tex_x -= this->world->sky->w;
	while (tex_x < 0)                    tex_x += this->world->sky->w;

	*canvas_at(this->canv, col->x, y) = *canvas_at(this->world->sky, tex_x, tex_y);
}

static void scene_render_sky_floor_pixel(scene_t *this, column_t *col, float off, int y) {
	if (this->cam.z <= this->world->sky_floor_h)
		return;

	float dist = this->sky_sh / off;

	float pos_x = this->cam.x + dist * this->dx;
	float pos_y = this->cam.y + dist * this->dy;

	float norm_x = pos_x - floor(pos_x);
	float norm_y = pos_y - floor(pos_y);

	float fog = scene_calc_fog(this, dist);

	int tex_x, tex_y;
	scene_get_surface_tex_pos(this, this->world->sky_floor_id, norm_x, norm_y, &tex_x, &tex_y);
	uint8_t color = *canvas_at(this->world->sheet.canv, tex_x, tex_y);

	if (fog > 0)
		color = color_shade(color, 0.5 + fog / 2);

	*canvas_at(this->canv, col->x, y) = color;
}

static void scene_render_surface_pixel(scene_t *this, column_t *col, float sh, float off,
                                       int surface, int y, int forced_id) {
	float dist  = sh / off;
	float pos_x = this->cam.x + dist * this->dx;
	float pos_y = this->cam.y + dist * this->dy;

	if (forced_id == -1)
		world_put_point_in_bounds(this->world, &pos_x, &pos_y, false);

	float norm_x = pos_x - floor(pos_x);
	float norm_y = pos_y - floor(pos_y);

	uint8_t id;
	if (forced_id < 0) {
		tile_t *tile = WORLD_AT(this->world, pos_x, pos_y);

		uint8_t split_side = tile_get_point_split_side(tile, norm_x, norm_y);
		UNUSED(split_side);
		if (*tile->type != FLOOR)
			return;

		if (surface == SURFACE_FLOOR) {
			id = *tile->floor_id;
			if (id == SKY) {
				scene_render_sky_floor_pixel(this, col, off, y);
				return;
			}
		} else {
			id = *tile->ceil_id;
			if (id == SKY) {
				scene_render_sky_ceil_pixel(this, col, y);
				return;
			}
		}
	} else
		id = forced_id;

	float fog = scene_calc_fog(this, dist);

	/* TODO: Temporary */
	//if (surface == SURFACE_FLOOR)
	//	fog -= *tile->floor_h / 2;
	//else
	//	fog += (*tile->ceil_h - 1) / 2;

	if (fog < 0) fog = 0;
	if (fog > 1) fog = 1;

	uint8_t color;
	if (fog == 1)
		color = BLACK;
	else {
		int tex_x, tex_y;
		scene_get_surface_tex_pos(this, id, norm_x, norm_y, &tex_x, &tex_y);
		color = *canvas_at(this->world->sheet.canv, tex_x, tex_y);

		if (fog > 0)
			color = color_shade(color, 0.5 + fog / 2);
	}

	*canvas_at(this->canv, col->x, y) = color;
}

static void scene_render_ceil(scene_t *this, column_t *col) {
	if (this->cam.z >= col->sect->ceil_h)
		return;

	int end = col->ceil_end;
	if (end > col->end)
		end = col->end;

	for (int y = col->start; y <= end; ++ y) {
		float sh  = this->canv->h - this->canv->h * (this->cam.z - (col->sect->ceil_h - 1));
		float off = col->d_fix * (this->center_y - y + this->cam_off);

		scene_render_surface_pixel(this, col, sh, off, SURFACE_CEIL, y, -1);
	}
}

static void scene_render_floor(scene_t *this, column_t *col) {
	if (this->cam.z <= col->sect->floor_h)
		return;

	int start = col->floor_start;
	if (start < col->start)
		start = col->start;

	for (int y = start; y <= col->end; ++ y) {
		float sh  = this->canv->h * (this->cam.z - col->sect->floor_h);
		float off = col->d_fix * (y - this->center_y - this->cam_off + 1);
		//float off = col->d_fix * (y - start + prev - this->center_y - this->cam_off + 1);

		if (off <= 0.2)
			continue;

		//if (y < prev)
		//	off = col->d_fix * (y - start + prev - this->center_y - this->cam_off + 1);


		int id = -1;
		// dont draw the waves on a sky wall
		if (col->sect->wave)
			id = col->sect->wave_id;

		// id is used to force a specific texture to be drawn on the surface pixel. if its -1,
		// the function searches for a texture in the map.
		scene_render_surface_pixel(this, col, sh, off, SURFACE_FLOOR, y, id);
	}
}

static void scene_render_wall(scene_t *this, column_t *col) {
	int y_off, start = col->wall1_start;
	if (start < col->start) {
		y_off = (col->start - start);
		start = col->start;
	} else
		y_off = 0;

	float fog = scene_calc_fog(this, col->sect->dist);
	if (this->world->shadow > 0) {
		if (col->sect->mid) {
			/* TODO: Make the middle wall shadow depend on the angle */
			fog += this->world->shadow / 2;
			if (fog > 1)
				fog = 1;
		} else if (this->world->shadow_vert? col->sect->side < 2 : col->sect->side >= 2) {
			fog += this->world->shadow;
			if (fog > 1)
				fog = 1;
		}
	}

	float   x_off = 0;
	tile_t *tile  = col->sect->tile;

	if (col->sect->mid) {
		float x = col->sect->x - col->sect->tile_x;
		float y = col->sect->y - col->sect->tile_y;

		if (tile->split == SPLIT_HORZ)
			y -= tile->p1;
		else
			x -= tile->p1;

		x_off = hypot(x, y);
	} else {
		bool invert = false;
		switch (col->sect->side) {
		case SIDE_DOWN: invert = true;
			/* Fall through */
		case SIDE_UP: x_off = col->sect->x - col->sect->tile_x; break;

		case SIDE_LEFT: invert = true;
			/* Fall through */
		case SIDE_RIGHT: x_off = col->sect->y - col->sect->tile_y; break;

		default: break;
		}

		if (invert)
			x_off = 1 - x_off;
	}

	uint8_t id    = 0;
	int     tex_x = 0;
	if (!col->sect->fog) {
		uint8_t wall_side = col->sect->mid? 4 : col->sect->side;

		id    = tile->wall_id[wall_side];
		tex_x = (x_off + tile->wall_off[wall_side]) * this->world->sheet.tile_size;
	}

	int end = col->wall1_start + col->wall1_h;
	if (end > col->end)
		end = col->end;

	if (id == SKY) {
		for (int y = start; y <= end; ++ y) {
			if (y > this->center_y + this->cam_off) {
				float off = col->d_fix * (y - this->center_y - this->cam_off);
				scene_render_sky_floor_pixel(this, col, off, y);
			} else
				scene_render_sky_ceil_pixel(this, col, y);
		}
		return;
	}

	float tex_y_step = (float)this->world->sheet.tile_size / (col->wall1_h / col->wall1_uh);
	float tex_y      = tex_y_step * y_off;
	for (int y = start; y <= end; ++ y) {
		uint8_t color;
		if (col->sect->fog || fog == 1)
			color = BLACK;
		else {
			/* This is probably slower but more precise:
			 * int tex_y = (float)(i + y_off) / h * this->world->sheet.tile_size;
			 */

			int tex_y_adjust = tex_y;
			int tex_x_adjust = tex_x;

			if (SHEET_ID_HAS_WAVES(&this->world->sheet, id)) {
				//tex_x_adjust += scene_calc_wave(this, tex_y / (this->world->sheet.tile_size * col->wall1_uh));
				//tex_y_adjust += scene_calc_wave(this, x_off);
				tex_y_adjust += scene_calc_fall(this, x_off);
			}

			tex_pos_fix(&tex_y_adjust, this->world->sheet.tile_size);
			tex_pos_fix(&tex_x_adjust, this->world->sheet.tile_size);

			tex_y_adjust += SHEET_ID_TO_Y(&this->world->sheet, id);
			tex_x_adjust += SHEET_ID_TO_X(&this->world->sheet, id);
			color = *canvas_at(this->world->sheet.canv, tex_x_adjust, tex_y_adjust);

			tex_y += tex_y_step;

			if (fog > 0)
				color = color_shade(color, 0.5 + fog / 2);
		}

		*canvas_at(this->canv, col->x, y) = color;
	}
}

static void scene_render_wall2(scene_t *this, column_t *col) {
	int y_off, start = col->wall2_start;
	if (start < col->start) {
		y_off = (col->start - start);
		start = col->start;
	} else
		y_off = 0;

	float fog = scene_calc_fog(this, col->sect->dist);
	if (this->world->shadow > 0) {
		if (col->sect->mid) {
			/* TODO: Make the middle wall shadow depend on the angle */
			fog += this->world->shadow / 2;
			if (fog > 1)
				fog = 1;
		} else if (this->world->shadow_vert? col->sect->side < 2 : col->sect->side >= 2) {
			fog += this->world->shadow;
			if (fog > 1)
				fog = 1;
		}
	}

	float   x_off = 0;
	tile_t *tile  = col->sect->tile;

	if (col->sect->mid) {
		float x = col->sect->x - col->sect->tile_x;
		float y = col->sect->y - col->sect->tile_y;

		if (tile->split == SPLIT_HORZ)
			y -= tile->p1;
		else
			x -= tile->p1;

		x_off = hypot(x, y);
	} else {
		bool invert = false;
		switch (col->sect->side) {
		case SIDE_DOWN: invert = true;
			/* Fall through */
		case SIDE_UP: x_off = col->sect->x - col->sect->tile_x; break;

		case SIDE_LEFT: invert = true;
			/* Fall through */
		case SIDE_RIGHT: x_off = col->sect->y - col->sect->tile_y; break;

		default: break;
		}

		if (invert)
			x_off = 1 - x_off;
	}

	uint8_t id    = 0;
	int     tex_x = 0;
	if (!col->sect->fog) {
		uint8_t wall_side = col->sect->mid? 4 : col->sect->side;

		id    = tile->wall_id[wall_side];
		tex_x = (x_off + tile->wall_off[wall_side]) * this->world->sheet.tile_size;
	}

	int end = col->wall2_start + col->wall2_h;
	if (end > col->end)
		end = col->end;

	if (id == SKY) {
		for (int y = start; y <= end; ++ y) {
			if (y > this->center_y + this->cam_off) {
				float off = col->d_fix * (y - this->center_y - this->cam_off);
				scene_render_sky_floor_pixel(this, col, off, y);
			} else
				scene_render_sky_ceil_pixel(this, col, y);
		}
		return;
	}

	float tex_y_step = (float)this->world->sheet.tile_size / (col->wall2_h / col->wall2_uh);
	float tex_y      = tex_y_step * y_off;
	for (int y = start; y <= end; ++ y) {
		uint8_t color;
		if (col->sect->fog || fog == 1)
			color = BLACK;
		else {
			/* This is probably slower but more precise:
			 * int tex_y = (float)(i + y_off) / h * this->world->sheet.tile_size;
			 */

			int tex_y_adjust = tex_y;
			int tex_x_adjust = tex_x;

			if (SHEET_ID_HAS_WAVES(&this->world->sheet, id)) {
				//tex_x_adjust += scene_calc_wave(this, tex_y / this->world->sheet.tile_size);
				//tex_y_adjust += scene_calc_wave(this, x_off);
				tex_y_adjust += scene_calc_fall(this, x_off);
			}

			tex_pos_fix(&tex_y_adjust, this->world->sheet.tile_size);
			tex_pos_fix(&tex_x_adjust, this->world->sheet.tile_size);

			tex_y_adjust += SHEET_ID_TO_Y(&this->world->sheet, id);
			tex_x_adjust += SHEET_ID_TO_X(&this->world->sheet, id);
			color = *canvas_at(this->world->sheet.canv, tex_x_adjust, tex_y_adjust);

			tex_y += tex_y_step;

			if (fog > 0)
				color = color_shade(color, 0.5 + fog / 2);
		}

		*canvas_at(this->canv, col->x, y) = color;
	}
}

static void scene_render_column(scene_t *this, column_t *col, int *new_start, int *new_end) {
	if (col->sect->dist == 0)
		return;

	float dist    = col->sect->dist * col->d_fix;
	float unit    = (float)this->canv->h / dist;
	float fwall_h = unit * col->sect->h;
	float off     = unit * -col->sect->floor_h + unit * this->cam.z;

	float wave;
	if (col->sect->wave && col->sect->tile->wall_id[col->sect->side] != SKY) {
		//float n;
		//if (col->sect->side <= SIDE_UP)
		//	n = col->sect->x - col->sect->tile_x;
		//else
		//	n = col->sect->y - col->sect->tile_y;

		float n = col->sect->side <= SIDE_UP? col->sect->x : col->sect->y;
		wave = (cos(n * M_PI * 2 + (float)this->tick * WAVE_SPEED) + 1) * unit * WAVE_HEIGHT; // * (1 - n);
	} else
		wave = 0;

	if (col->wall) {
		col->wall1_start = round(this->center_y - (fwall_h - off) + this->cam_off);
		col->wall1_h     = round(fwall_h);
		col->wall1_uh    = col->sect->h;
		col->floor_start = col->wall1_start + col->wall1_h;
		col->ceil_end    = col->wall1_start - 1;

		// TODO: Temporary
		col->floor_start -= wave;

		scene_render_wall (this, col);
		scene_render_floor(this, col);
		scene_render_ceil (this, col);
	} else {
		/* TODO: Angled walls support */
		col->wall1_uh = col->sect->ceil_h - *col->sect->tile->ceil_h;
		col->wall2_uh = *col->sect->tile->floor_h - col->sect->floor_h;
		float fwall1_h = unit * col->wall1_uh;
		float fwall2_h = unit * col->wall2_uh;

		if (fwall1_h < 0) fwall1_h = 0;
		if (fwall2_h < 0) fwall2_h = 0;

		float fspace_h = round(fwall_h - round(fwall1_h) - round(fwall2_h));

		col->wall1_start = ceil(this->center_y - (fwall_h - off) + this->cam_off);
		col->wall1_h     = ceil(fwall1_h);

		col->wall2_start = col->wall1_start + col->wall1_h + fspace_h - 1;
		col->wall2_h     = round(fwall2_h);

		col->floor_start = col->wall2_start + col->wall2_h;
		col->ceil_end    = col->wall1_start - 1;

		// TODO: Temporary
		col->floor_start -= wave;

		if (fwall1_h > 0)
			scene_render_wall(this, col);

		if (fwall2_h > 0)
			scene_render_wall2(this, col);

		scene_render_floor(this, col);
		scene_render_ceil (this, col);

		*new_start = col->wall1_start + col->wall1_h;
		*new_end   = col->wall2_start - 1;

		if (*new_start < col->start)
			*new_start = col->start;

		if (*new_end > col->end)
			*new_end = col->end;
	}
}

static column_t column_new(sector_t *sect, int x, int start, int end, float d_fix, bool wall) {
	return (column_t){
		.sect   = sect,
		.x      = x,
		.start  = start,
		.end    = end,
		.h      = end - start,
		.h_half = (float)(end - start + 1) / 2,
		.d_fix  = d_fix,
		.wall   = wall,
	};
}

static void scene_calc_wave_off_map(scene_t *this) {
	float wave_off  = this->tick * WAVE_SPEED;
	float wave_size = WAVE_SIZE * this->world->sheet.tile_size;
	for (int i = 0; i < this->world->sheet.tile_size; ++ i) {
		float off = (float)i / this->world->sheet.tile_size;
		this->wave_off_map[i] = sin(off * M_PI * 2 + wave_off) * wave_size;
	}
}

static void scene_calc_fall_off_map(scene_t *this) {
	float fall_off  = this->tick * WAVE_SPEED * 18;
	float fall_size = WAVE_SIZE * this->world->sheet.tile_size;
	for (int i = 0; i < this->world->sheet.tile_size; ++ i) {
		float off  = (float)i / this->world->sheet.tile_size;
		float fall = (fabs(sin(off * 10 * M_PI)) * 0.6 + 0.4) * fall_off;
		this->fall_off_map[i] = (int)((sin(off * M_PI * 2) - fall) * fall_size) %
		                        this->world->sheet.tile_size;
	}
}

void scene_render(scene_t *this) {
	scene_calc_wave_off_map(this);
	scene_calc_fall_off_map(this);
	this->sky_sh = this->canv->h * (this->cam.z - this->world->sky_floor_h);

	for (int x = 0; x < this->canv->w; ++ x) {
		float d  = this->cam.d + this->x_to_d_map[x];
		this->dx = cos(d);
		this->dy = sin(d);

		sector_t sects[SECTORS_CAP];
		int count = scene_raycast(this, sects);
		UNUSED(count);

		int start = 0;
		int end   = this->canv->h - 1;
		for (int i = 0; i < count; ++ i) {
			column_t col = column_new(sects + i, x, start, end,
			                          cos(this->x_to_d_map[x]), i + 1 == count);

			scene_render_column(this, &col, &start, &end);
		}
	}

	++ this->tick;
}

void ray_init(ray_t *this, float x, float y, float dx, float dy) {
	this->start_x = x;
	this->start_y = y;
	this->dx      = dx;
	this->dy      = dy;
	this->x       = floor(x);
	this->y       = floor(y);

	this->len_step_x = hypot(1, this->dy / this->dx);
	this->len_step_y = hypot(this->dx / this->dy, 1);

	if (this->dx < 0) {
		this->step_x = -1;
		this->len_x  = (this->start_x - this->x) * this->len_step_x;
	} else {
		this->step_x = 1;
		this->len_x  = ((float)this->x + 1 - this->start_x) * this->len_step_x;
	}

	if (this->dy < 0) {
		this->step_y = -1;
		this->len_y  = (this->start_y - this->y) * this->len_step_y;
	} else {
		this->step_y = 1;
		this->len_y  = ((float)this->y + 1 - this->start_y) * this->len_step_y;
	}

	this->horz        = this->len_y > this->len_x;
	this->dist        = 0;
	this->can_collide = false;
	this->stepped     = false;
}

void ray_step(ray_t *this) {
	if (!this->stepped)
		this->stepped = true;

	if (this->len_y > this->len_x) {
		this->horz = true;
		this->dist = this->len_x;

		this->len_x += this->len_step_x;
		this->x     += this->step_x;
	} else {
		this->horz = false;
		this->dist = this->len_y;

		this->len_y += this->len_step_y;
		this->y     += this->step_y;
	}
}

line_t ray_get_line_in_tile(ray_t *ray) {
	line_t line;

	if (!ray->stepped) {
		line.x1 = ray->start_x - ray->x;
		line.y1 = ray->start_y - ray->y;

		if (ray->horz) {
			line.x2 = ray->dx >= 0;
			line.y2 = ray->start_y + ray->dy * ray->len_x - ray->y;
		} else {
			line.x2 = ray->start_x + ray->dx * ray->len_y - ray->x;
			line.y2 = ray->dy >= 0;
		}
	} else {
		if (ray->horz) {
			line.x1 = ray->dx < 0;
			line.y1 = ray->start_y + ray->dy * ray->dist - ray->y;

			line.x2 = ray->dx >= 0;
			line.y2 = ray->start_y + ray->dy * ray->len_x - ray->y;
		} else {
			line.x1 = ray->start_x + ray->dx * ray->dist - ray->x;
			line.y1 = ray->dy < 0;

			line.x2 = ray->start_x + ray->dx * ray->len_y - ray->x;
			line.y2 = ray->dy >= 0;
		}
	}

	return line;
}

void ray_enable_collision(ray_t *this) {
	if (!this->can_collide)
		this->can_collide = true;
}
