#include "video.h"

video_t video;

void video_init(const char *title, int w, int h, video_opts_t opts) {
	assert(colorinfo.pal != NULL && "Please load the palette before initializing the video");

	video.title = title;
	video.scale = opts.scale;
	video.w     = video.scale * w;
	video.h     = video.scale * h;
	video.min_w = video.scale * opts.min_w;
	video.min_h = video.scale * opts.min_h;
	video.scr   = canvas_new(w, h);
	video.buf   = (uint32_t*)xalloc(video.scr->size * sizeof(uint32_t));

	video.resizable = opts.resizable;

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
		LOG_FATAL("Failed to initialize SDL2: %s", SDL_GetError());

	LOG_INFO("Initialized SDL2");

	const char *hint = opts.antialias? "linear" : "nearest";
	if (!SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, hint))
		LOG_FATAL("Failed to set render scale quality hint: %s", SDL_GetError());

	int flags = SDL_WINDOW_SHOWN;
	if (opts.fullscr)   flags |= SDL_WINDOW_FULLSCREEN;
	if (opts.resizable) flags |= SDL_WINDOW_RESIZABLE;

	video.win = SDL_CreateWindow(video.title, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
	                             video.w, video.h, flags);
	if (video.win == NULL)
		LOG_FATAL("Failed to create window \"%s\": %s", video.title, SDL_GetError());

	SDL_SetWindowMinimumSize(video.win, video.min_w, video.min_h);

	video.ren = SDL_CreateRenderer(video.win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (video.ren == NULL)
		LOG_FATAL("Failed to create window renderer: %s", SDL_GetError());

	video.tex = SDL_CreateTexture(video.ren, SDL_PIXELFORMAT_ABGR8888,
	                              SDL_TEXTUREACCESS_STREAMING, video.scr->w, video.scr->h);
	if (video.tex == NULL)
		LOG_FATAL("Failed to create window texture: %s", SDL_GetError());

	LOG_INFO("Initialized video in window \"%s\"", video.title);
}

void video_deinit(void) {
	canvas_destroy(video.scr);
	xfree(video.buf);

	SDL_DestroyTexture(video.tex);
	SDL_DestroyRenderer(video.ren);
	SDL_DestroyWindow(video.win);
	LOG_INFO("Deinitialized video in window \"%s\"", video.title);

	SDL_Quit();
	LOG_INFO("Deinitialized SDL2");

	colorinfo_clean();
}

void video_display(void) {
	for (int i = 0; i < video.scr->size; ++ i)
		video.buf[i] = colorinfo.pal[video.scr->buf[i]];

	SDL_UpdateTexture(video.tex, NULL, video.buf, video.scr->w * 4);
	SDL_RenderCopy(video.ren, video.tex, NULL, NULL);
	SDL_RenderPresent(video.ren);
}

void video_resized(int w, int h) {
	if (!video.resizable)
		return;

	int prev_w = video.w;
	int prev_h = video.h;

	video.w = w;
	video.h = h;

	bool fix_size = false;
	if (video.w < video.min_w) {
		video.w  = video.min_w;
		fix_size = true;
	}

	if (video.h < video.min_h) {
		video.h  = video.min_h;
		fix_size = true;
	}

	if (fix_size)
		SDL_SetWindowSize(video.win, video.w, video.h);

	if (video.w == prev_w && video.h == prev_h)
		return;

	int prev_size = video.scr->size;
	canvas_resize(video.scr, video.w / video.scale, video.h / video.scale);

	if (video.scr->size != prev_size)
		video.buf = (uint32_t*)xrealloc(video.buf, video.scr->size * sizeof(uint32_t));

	SDL_DestroyTexture(video.tex);

	video.tex = SDL_CreateTexture(video.ren, SDL_PIXELFORMAT_ABGR8888,
	                              SDL_TEXTUREACCESS_STREAMING, video.scr->w, video.scr->h);
	if (video.tex == NULL)
		LOG_FATAL("Failed to resize window texture: %s", SDL_GetError());

	LOG_INFO("Window resized to %i:%i", video.w, video.h);
}

void video_show_cursor(bool show) {
	if (SDL_ShowCursor(show? SDL_ENABLE : SDL_DISABLE) < 0)
		LOG_FATAL("Failed to disable the mouse cursor: %s", SDL_GetError());

	LOG_INFO("The mouse cursor was %s", show? "enabled" : "disabled");
}
