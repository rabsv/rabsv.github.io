#include "game.h"

game_t *game_new(const char *path, float scale, bool antialias, bool fullscr) {
	game_t *this = NEW(game_t);

	load_palette_bmp(0, "./res/palette1.bmp");
	load_colormap_lmp("./res/colormap.lmp");

	video_opts_t opts = {
		.scale     = scale,
		.antialias = antialias,
		.fullscr   = fullscr,
	};
	video_init(path, WIN_W, WIN_H, opts);

	this->font     = font_load_lmp("./res/font.lmp",     6, 8);
	this->fontbold = font_load_lmp("./res/fontbold.lmp", 8, 8);

	this->keys = SDL_GetKeyboardState(NULL);

	world_init(&this->world, "./res/sheet.lmp", 64, "./res/sky.lmp");
	scene_setup(&this->scene, &this->world, video.scr, FOV);

	this->cam.x = this->world.plr->x;
	this->cam.y = this->world.plr->y;
	this->cam.z = this->world.plr->z;
	this->cam.d = this->world.plr->d;

	this->paused = true;

	fprintf(stderr, "===================== INITIALIZED ====================\n");
	return this;
}

void game_destroy(game_t *this) {
	fprintf(stderr, "======================= EXITING ======================\n");

	scene_cleanup(&this->scene);
	world_deinit(&this->world);

	font_destroy(this->font);
	font_destroy(this->fontbold);

	video_deinit();
	xfree(this);
}

static void game_events(game_t *this) {
	while (SDL_PollEvent(&this->evt)) {
		switch (this->evt.type) {
		case SDL_QUIT: this->quit = true; break;

		case SDL_WINDOWEVENT:
			if (this->evt.window.event == SDL_WINDOWEVENT_RESIZED) {
				video_resized(this->evt.window.data1, this->evt.window.data2);
				scene_resized(&this->scene);
			}
			break;

		case SDL_KEYDOWN:
			switch (this->evt.key.keysym.sym) {
			case SDLK_SPACE:
				this->paused = !this->paused;

				SDL_WarpMouseInWindow(video.win, video.w / 2, video.h / 2);
				video_show_cursor(this->paused);
				break;
			}
			break;

		case SDL_MOUSEMOTION: {
			if (this->paused)
				break;

			SDL_WarpMouseInWindow(video.win, video.w / 2, video.h / 2);

			float x = ((float)this->evt.motion.x - video.w / 2);
			float y = ((float)this->evt.motion.y - video.h / 2);
			this->cam.d  += DTOR((float)x / FOV * SENSIT);
			this->cam.zd -= DTOR((float)y / FOV * SENSIT);

			if (this->cam.zd >  M_PI * 0.7) this->cam.zd =  M_PI * 0.7;
			if (this->cam.zd < -M_PI * 0.7) this->cam.zd = -M_PI * 0.7;
		} break;

		default: break;
		}
	}

	if (this->keys[SDL_SCANCODE_W]) {
		this->cam.x += cos(this->cam.d) * CAM_SPEED;
		this->cam.y += sin(this->cam.d) * CAM_SPEED;
		this->cam.z += this->cam.zd / M_PI * 2 * CAM_SPEED;

		world_put_point_in_bounds(&this->world, &this->cam.x, &this->cam.y);
	}

	if (this->keys[SDL_SCANCODE_S]) {
		this->cam.x -= cos(this->cam.d) * CAM_SPEED;
		this->cam.y -= sin(this->cam.d) * CAM_SPEED;
		this->cam.z -= this->cam.zd / M_PI * 2 * CAM_SPEED;

		world_put_point_in_bounds(&this->world, &this->cam.x, &this->cam.y);
	}

	if (this->keys[SDL_SCANCODE_A]) {
		this->cam.x -= cos(this->cam.d + M_PI / 2) * CAM_SPEED;
		this->cam.y -= sin(this->cam.d + M_PI / 2) * CAM_SPEED;

		world_put_point_in_bounds(&this->world, &this->cam.x, &this->cam.y);
	}

	if (this->keys[SDL_SCANCODE_D]) {
		this->cam.x += cos(this->cam.d + M_PI / 2) * CAM_SPEED;
		this->cam.y += sin(this->cam.d + M_PI / 2) * CAM_SPEED;

		world_put_point_in_bounds(&this->world, &this->cam.x, &this->cam.y);
	}
}

void game_update(game_t *this) {
	game_events(this);

	size_t now  = SDL_GetTicks();
	size_t diff = now - this->fps_timer;
	if (diff > 0)
		this->fps = 1000 / diff;

	this->fps_timer = now;

	++ this->tick;
}

void game_render(game_t *this) {
	canvas_clear(video.scr);

	scene_set_camera(&this->scene, this->cam);
	scene_render(&this->scene);

	if (this->paused) {
		canvas_rect_dither(video.scr, NULL, BLACK);

		const char *txt = "PAUSED";
		int y = video.scr->h / 2 - this->fontbold->ch_h / 2 * 2;
		int x = video.scr->w / 2 - this->fontbold->ch_w * strlen(txt) / 2 * 2;

		font_render(this->fontbold, txt, video.scr, x, y, 2, -1);
	}

	char fps[32] = {0};
	snprintf(fps, sizeof(fps), "FPS: %zu", this->fps);
	font_render(this->font, fps, video.scr, 5, 5, 1, WHITE);

	video_display();
}
