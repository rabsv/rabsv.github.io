#include <stdio.h>   /* fprintf, stderr */
#include <stdlib.h>  /* exit, EXIT_FAILURE, malloc, free */
#include <stdbool.h> /* bool, true, false */
#include <stdint.h>  /* uint32_t, uint64_t */
#include <math.h>    /* tan, round */

#include <SDL2/SDL.h>

#include "../pif.h"
#include "../pif.c"

#define TITLE      "3D stars"
#define WIN_W      600
#define WIN_H      440
#define SCALE      1
#define FOV        70
#define SENSIT     1
#define NEAR_PLANE 0.1
#define FAR_PLANE  1000

#define SCR_W        (WIN_W / SCALE)
#define SCR_H        (WIN_H / SCALE)
#define FOV_RAD      degToRad(FOV)
#define ASPECT_RATIO ((float)SCR_H / SCR_W)
#define PLANES_DIST  (FAR_PLANE - NEAR_PLANE)

#ifndef M_PI
#	define M_PI 3.1415926535
#endif

#define degToRad(DEG) (DEG * (M_PI / 180))
#define arraySize(ARR) (sizeof(ARR) / sizeof(*(ARR)))
#define die(...)                   \
	(fprintf(stderr, __VA_ARGS__), \
	 fputc('\n', stderr),          \
	 exit(EXIT_FAILURE))

typedef struct {
	float x, y, z;
} Point;

typedef struct {
	Point ps[3];
} Triangle;

bool running = true, paused = false, rotate = false;

SDL_Window    *win;
SDL_Renderer  *ren;
SDL_Texture   *scr;
uint32_t      *pixels;
const uint8_t *keyboard;

int winW = WIN_W, winH = WIN_H;

PIF_Palette *pal;
PIF_Image   *canv, *colormap;
uint8_t      starColor, bgColor;

Point  cam = {0, 2, 10};
float  camDirY, camDirZ, projMat[4][4];
double dt, elapsedTime;

// TODO: Store vertices in a separate buffer and index them from triangles
typedef struct {
	Triangle *tris;
	int       trisCount;
} Mesh;

Point midpoint;
Mesh  mesh;

Triangle cube[] = {
	/* Front */
	{{
		{ 1,  1, 1},
		{ 1, -1, 1},
		{-1,  1, 1},
	}},
	{{
		{-1, -1, 1},
		{ 1, -1, 1},
		{-1,  1, 1},
	}},
	/* Back */
	{{
		{ 1,  1, -1},
		{ 1, -1, -1},
		{-1,  1, -1},
	}},
	{{
		{-1, -1, -1},
		{ 1, -1, -1},
		{-1,  1, -1},
	}},
	/* Top */
	{{
		{ 1, 1, -1},
		{ 1, 1,  1},
		{-1, 1, -1},
	}},
	{{
		{-1, 1,  1},
		{ 1, 1,  1},
		{-1, 1, -1},
	}},
	/* Bottom */
	{{
		{ 1, -1, -1},
		{ 1, -1,  1},
		{-1, -1, -1},
	}},
	{{
		{-1, -1,  1},
		{ 1, -1,  1},
		{-1, -1, -1},
	}},
	/* Left */
	{{
		{1,  1, -1},
		{1, -1, -1},
		{1,  1,  1},
	}},
	{{
		{1, -1,  1},
		{1, -1, -1},
		{1,  1,  1},
	}},
	/* Right */
	{{
		{-1,  1, -1},
		{-1, -1, -1},
		{-1,  1,  1},
	}},
	{{
		{-1, -1,  1},
		{-1, -1, -1},
		{-1,  1,  1},
	}},
};

static void calcProjMatrix(void) {
	float scale = 1 / tan(FOV_RAD / 2);
	float q     = FAR_PLANE / PLANES_DIST;

	projMat[0][0] = scale * ASPECT_RATIO;
	projMat[1][1] = scale;
	projMat[2][2] = q;
	projMat[3][2] = -NEAR_PLANE * q;
	projMat[2][3] = 1;
}

static void setup(const char *palPath, const char *objPath) {
	if (objPath == NULL) {
		mesh.tris      = cube;
		mesh.trisCount = arraySize(cube);
	} else {
		FILE *file = fopen(objPath, "r");
		if (file == NULL)
			die("Error: Failed to read object file \"%s\"", objPath);

		int psCap = 0, psCount = 0, trisCap = 0;
		while (!feof(file)) {
			char ch = fgetc(file);
			if      (ch == 'v') ++ psCap;
			else if (ch == 'f') ++ trisCap;
		}
		rewind(file);

		Point *ps = (Point*)malloc(psCap * sizeof(Point));
		mesh.tris = (Triangle*)malloc(trisCap * sizeof(Triangle));
		while (!feof(file)) {
		a:
			(void)NULL;
			char ch = fgetc(file);
			if (ch == '\n')
				goto a;

			char ch2 = fgetc(file);
			if (feof(file))
				break;
			if (ch == 'v' && ch2 == ' ') {
				Point *p = ps + psCount ++;
				int _ = fscanf(file, "%f %f %f", &p->x, &p->y, &p->z);
				(void)_;
			} else if (ch == 'f' && ch2 == ' ') {
				char as[100], bs[100], cs[100];
				int _ = fscanf(file, "%s %s %s", as, bs, cs);
				(void)_;

				int a = atof(as);
				int b = atof(bs);
				int c = atof(cs);

				mesh.tris[mesh.trisCount].ps[0] = ps[a - 1];
				mesh.tris[mesh.trisCount].ps[1] = ps[b - 1];
				mesh.tris[mesh.trisCount].ps[2] = ps[c - 1];
				++ mesh.trisCount;
			} else {
				char buf[10000];
				char *_ = fgets(buf, sizeof(buf), file);
				(void)_;
			}
		}

		for (int i = 0; i < psCount; ++ i) {
			midpoint.x += ps[i].x;
			midpoint.y += ps[i].y;
			midpoint.z += ps[i].z;
		}
		midpoint.x /= psCount;
		midpoint.y /= psCount;
		midpoint.z /= psCount;
		free(ps);
	}


	const char *err;
	pal = PIF_paletteLoad(palPath, &err);
	if (pal == NULL)
		die("Error: %s", err);

	colormap = PIF_paletteCreateColormap(pal, 64, 0.4);
	canv     = PIF_imageNew(SCR_W, SCR_H);
	pixels   = (uint32_t*)malloc(canv->size * sizeof(uint32_t));

	PIF_imageSetColormap(canv, colormap);

	starColor = PIF_paletteClosest(pal, (PIF_Rgb){50, 150, 255});
	bgColor   = PIF_paletteClosest(pal, (PIF_Rgb){0,  0,   0});

	if (SDL_Init(SDL_INIT_VIDEO) < 0)
		die("Failed to initialize SDL2: %s", SDL_GetError());

	win = SDL_CreateWindow(TITLE, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
	                       WIN_W, WIN_H, SDL_WINDOW_SHOWN);
	if (win == NULL)
		die("Failed to create window: %s", SDL_GetError());

	ren = SDL_CreateRenderer(win, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
	if (ren == NULL)
		die("Failed to create renderer: %s", SDL_GetError());

	scr = SDL_CreateTexture(ren, SDL_PIXELFORMAT_RGBA8888, SDL_TEXTUREACCESS_STREAMING,
	                        SCR_W, SCR_H);
	if (scr == NULL)
		die("Failed to create screen texture: %s", SDL_GetError());

	//if (SDL_RenderSetLogicalSize(ren, SCR_W, SCR_H) < 0)
	//	die("Failed to set logical render size: %s", SDL_GetError());

	keyboard = SDL_GetKeyboardState(NULL);

	SDL_SetWindowResizable(win, true); /* A hack to force i3wm to float the window on startup */
	SDL_SetRelativeMouseMode(SDL_TRUE);

	calcProjMatrix();
}

static void cleanup(void) {
	SDL_DestroyTexture(scr);
	SDL_DestroyRenderer(ren);
	SDL_DestroyWindow(win);

	SDL_Quit();

	free(pixels);
	PIF_imageFree(canv);
	PIF_imageFree(colormap);
	PIF_paletteFree(pal);
}

static void mulVector4ByMatrix4x4(float vec[4], float mat[4][4], float result[4]) {
/* Not sure which approach is faster (this one might get optimized with SIMD), so I'm keeping
   both around just in case

	result[0] = vec[0] * mat[0][0] + vec[1] * mat[1][0] + vec[2] * mat[2][0] + vec[3] * mat[3][0];
	result[1] = vec[0] * mat[0][1] + vec[1] * mat[1][1] + vec[2] * mat[2][1] + vec[3] * mat[3][1];
	result[2] = vec[0] * mat[0][2] + vec[1] * mat[1][2] + vec[2] * mat[2][2] + vec[3] * mat[3][2];
	result[3] = vec[0] * mat[0][3] + vec[1] * mat[1][3] + vec[2] * mat[2][3] + vec[3] * mat[3][3];
*/

	for (int x = 0; x < 4; ++ x) {
		float sum = 0;
		for (int y = 0; y < 4; ++ y)
			sum += vec[y] * mat[y][x];

		result[x] = sum;
	}
}

static void mulPointByMatrix4x4(Point *p, float mat[4][4]) {
	float result[4], vec[4] = {p->x, p->y, p->z, 1};
	mulVector4ByMatrix4x4(vec, mat, result);

	if (result[3] != 0) {
		for (int i = 0; i < 3; ++ i)
			result[i] /= result[3];
	}

	p->x = result[0];
	p->y = result[1];
	p->z = result[2];
}

static void projectPoint(Point p, int *scrX, int *scrY) {
	// TODO: for some reason, models are inverted?
	p.y *= -1;

	p.x += midpoint.x;
	p.y += midpoint.y;
	p.z += midpoint.z;

	if (rotate) {
		float xRotMat[4][4] = {0};
		xRotMat[0][0] =  cos(elapsedTime / 1000);
		xRotMat[1][0] =  sin(elapsedTime / 1000);
		xRotMat[0][1] = -sin(elapsedTime / 1000);
		xRotMat[1][1] =  cos(elapsedTime / 1000);
		xRotMat[2][2] =  1;
		mulPointByMatrix4x4(&p, xRotMat);

		float zRotMat[4][4] = {0};
		zRotMat[0][0] =  1;
		zRotMat[1][1] =  cos(elapsedTime / 1000);
		zRotMat[2][1] =  sin(elapsedTime / 1000);
		zRotMat[1][2] = -sin(elapsedTime / 1000);
		zRotMat[2][2] =  cos(elapsedTime / 1000);
		mulPointByMatrix4x4(&p, zRotMat);
	}

	p.x -= midpoint.x;
	p.y -= midpoint.y;
	p.z -= midpoint.z;

	p.x += cam.x;
	p.y += cam.y;
	p.z += cam.z;

	float camYRotMat[4][4] = {0};
	camYRotMat[0][0] =  cos(camDirY);
	camYRotMat[2][0] =  sin(camDirY);
	camYRotMat[0][2] = -sin(camDirY);
	camYRotMat[2][2] =  cos(camDirY);
	camYRotMat[1][1] =  1;
	mulPointByMatrix4x4(&p, camYRotMat);

	float camZRotMat[4][4] = {0};
	camZRotMat[0][0] =  1;
	camZRotMat[1][1] =  cos(camDirZ);
	camZRotMat[2][1] =  sin(camDirZ);
	camZRotMat[1][2] = -sin(camDirZ);
	camZRotMat[2][2] =  cos(camDirZ);
	mulPointByMatrix4x4(&p, camZRotMat);

	mulPointByMatrix4x4(&p, projMat);

	*scrX = (1 + p.x) / 2 * SCR_W;
	*scrY = (1 + p.y) / 2 * SCR_H;
}

static void renderTriangle(Triangle *tri, uint8_t color) {
// cross product test
//	float dx1 = tri->ps[1].x - tri->ps[0].x;
//	float dx2 = tri->ps[1].x - tri->ps[2].x;
//
//	float dy1 = tri->ps[1].y - tri->ps[0].y;
//	float dy2 = tri->ps[1].y - tri->ps[2].y;
//
//	float crossZ = dx1 * dy2 - dx2 * dy1;
//	if (crossZ < 0)
//		return;

	int x1, y1, x2, y2, x3, y3;
	projectPoint(tri->ps[0], &x1, &y1);
	projectPoint(tri->ps[1], &x2, &y2);
	projectPoint(tri->ps[2], &x3, &y3);

	PIF_imageFillTriangle(canv, x1, y1, x2, y2, x3, y3, color);
}

static void render(void) {
	SDL_SetRenderDrawColor(ren, 0, 0, 0, SDL_ALPHA_OPAQUE);
	SDL_RenderClear(ren);

	PIF_imageClear(canv, bgColor);

	PIF_imageSetBlendMode(canv, PIF_BlendModeColormap);

	for (int i = 0; i < mesh.trisCount; ++ i)
		renderTriangle(mesh.tris + i, (i * 2) % 20 + 1);

	PIF_imageSetBlendMode(canv, PIF_BlendModeNone);

	int size = 5;
	PIF_imageDrawLine(canv, SCR_W / 2, SCR_H / 2 - size, SCR_W / 2, SCR_H / 2 + size, 0, starColor);
	PIF_imageDrawLine(canv, SCR_W / 2 - size, SCR_H / 2, SCR_W / 2 + size, SCR_H / 2, 0, starColor);

	if (paused) {
		PIF_imageSetBlendMode(canv, PIF_BlendModeColormap);
		PIF_imageFillRect(canv, NULL, PIF_paletteClosest(pal, (PIF_Rgb){150, 150, 150}));
	}

	for (int i = 0; i < canv->size; ++ i)
		pixels[i] = PIF_rgbToPixelRgba32(pal->map[canv->buf[i]]);

	SDL_UpdateTexture(scr, NULL, pixels, canv->w * sizeof(*pixels));

	int w = winW;
	int h = winH;
	float winAspectRatio = (float)winH / winW;

	if      (winAspectRatio > ASPECT_RATIO) h = w * ASPECT_RATIO;
	else if (winAspectRatio < ASPECT_RATIO) w = h / ASPECT_RATIO;

	SDL_Rect rect = {
		.x = winW / 2 - w / 2,
		.y = winH / 2 - h / 2,
		.w = w,
		.h = h,
	};
	SDL_RenderCopy(ren, scr, NULL, &rect);
	SDL_RenderPresent(ren);
}

static void input(void) {
	SDL_Event evt;
	while (SDL_PollEvent(&evt)) {
		switch (evt.type) {
		case SDL_QUIT: running = false; break;

		case SDL_WINDOWEVENT:
			if (evt.window.event == SDL_WINDOWEVENT_RESIZED) {
				winW = evt.window.data1;
				winH = evt.window.data2;
			}
			break;

		case SDL_KEYDOWN:
			if (evt.key.keysym.sym == SDLK_SPACE) {
				paused = !paused;
				SDL_SetRelativeMouseMode(!paused);
			} else if (evt.key.keysym.sym == SDLK_ESCAPE)
				rotate = !rotate;
			break;

		case SDL_MOUSEMOTION:
			if (paused)
				break;

			camDirY -= (float)evt.motion.xrel / SCR_W * SENSIT;
			camDirZ -= (float)evt.motion.yrel / SCR_H * SENSIT;

			//this->cam.d  += DTOR((float)x / FOV * SENSIT);
//			this->cam.zd -= DTOR((float)y / FOV * SENSIT);
//
//			if (this->cam.zd >  M_PI * 0.7) this->cam.zd =  M_PI * 0.7;
//			if (this->cam.zd < -M_PI * 0.7) this->cam.zd = -M_PI * 0.7;
			break;
		}
	}

	if (paused)
		return;

	if (keyboard[SDL_SCANCODE_W]) {
		cam.x += sin(camDirY) * cos(camDirZ) / 4;
		cam.y += sin(camDirZ) / 4;
		cam.z -= cos(camDirY) * cos(camDirZ) / 4;
	}
	if (keyboard[SDL_SCANCODE_S]) {
		cam.x -= sin(camDirY) * cos(camDirZ) / 4;
		cam.y -= sin(camDirZ) / 4;
		cam.z += cos(camDirY) * cos(camDirZ) / 4;
	}
	if (keyboard[SDL_SCANCODE_A]) {
		cam.x += sin(camDirY + M_PI / 2) / 4;
		cam.z -= cos(camDirY + M_PI / 2) / 4;
	}
	if (keyboard[SDL_SCANCODE_D]) {
		cam.x += sin(camDirY - M_PI / 2) / 4;
		cam.z -= cos(camDirY - M_PI / 2) / 4;
	}

	//if (keyboard[SDL_SCANCODE_W]) cam.z -= 0.5;
	//if (keyboard[SDL_SCANCODE_S]) cam.z += 0.5;
	//if (keyboard[SDL_SCANCODE_A]) cam.x += 0.5;
	//if (keyboard[SDL_SCANCODE_D]) cam.x -= 0.5;
	if (keyboard[SDL_SCANCODE_Q])     cam.y   += 1.0 / 4;
	if (keyboard[SDL_SCANCODE_E])     cam.y   -= 1.0 / 4;
	if (keyboard[SDL_SCANCODE_LEFT])  camDirY += 0.05;
	if (keyboard[SDL_SCANCODE_RIGHT]) camDirY -= 0.05;
	if (keyboard[SDL_SCANCODE_UP])    camDirZ += 0.05;
	if (keyboard[SDL_SCANCODE_DOWN])  camDirZ -= 0.05;

	if (camDirZ > M_PI / 2)
		camDirZ = M_PI / 2;
	if (camDirZ < -M_PI / 2)
		camDirZ = -M_PI / 2;
}

int main(int argc, char **argv) {
	if (argc < 2)
		die("Usage: %s <PALETTE_PATH> [OBJ_PATH]", argv[0]);

	setup(argv[1], argv[2]);

	while (running) {
		static uint64_t last = 0, now = 0;
		last = now;
		now  = SDL_GetPerformanceCounter();
		dt   = (double)(now - last) * 1000 / (double)SDL_GetPerformanceFrequency();

		elapsedTime += dt;

		render();
		input();
	}

	cleanup();
}
