#include "gfx.h"

colorinfo_t colorinfo;

void colorinfo_clean(void) {
	if (colorinfo.colormap != NULL)
		xfree(colorinfo.colormap);

	for (int i = 0; i < PALS_CAP; ++ i) {
		if (colorinfo.pals[i] != NULL)
			xfree(colorinfo.pals[i]);
	}
}

void load_palette_bmp(int id, const char *path) {
	SDL_Surface *s = SDL_LoadBMP(path);
	if (s == NULL)
		LOG_FATAL("Failed to load palette \"%s\"", path);

	assert(s->w * s->h == COLORS);

	uint32_t *pal = (uint32_t*)xalloc(COLORS * sizeof(uint32_t));
	for (int i = 0; i < COLORS; ++ i) {
		uint32_t pixel = ((uint32_t*)s->pixels)[i];

		pal[i] = rgb_to_abgr32((pixel & s->format->Rmask) >> s->format->Rshift,
		                       (pixel & s->format->Gmask) >> s->format->Gshift,
		                       (pixel & s->format->Bmask) >> s->format->Bshift);
	}

	SDL_FreeSurface(s);
	colorinfo.pals[id] = pal;
	colorinfo.pal      = pal;
}

void use_palette(int id) {
	colorinfo.pal = colorinfo.pals[id];
}

static int file_read_u32(FILE *file, uint32_t *out) {
	uint8_t bytes[4];
	for (int i = 0; i < 4; ++ i) {
		int b = fgetc(file);
		if (b == EOF)
			return -1;

		bytes[i] = b;
	}

	*out = ((uint32_t)bytes[0])       |
	       ((uint32_t)bytes[1] << 8)  |
	       ((uint32_t)bytes[2] << 16) |
	       ((uint32_t)bytes[3] << 24);
	return 0;
}

void load_colormap_lmp(const char *path) {
	FILE *file = fopen(path, "rb");
	if (file == NULL)
		LOG_FATAL("Failed to load colormap \"%s\"", path);

	uint32_t w, h;
	if (file_read_u32(file, &w) != 0) LOG_FATAL("Colormap file \"%s\" is corrupted", path);
	if (file_read_u32(file, &h) != 0) LOG_FATAL("Colormap file \"%s\" is corrupted", path);

	assert(w == COLORS);
	assert(h == SHADES);

	colorinfo.colormap = (uint8_t*)xalloc(COLORS * SHADES);
	for (int i = 0; i < COLORS * SHADES; ++ i) {
		int b = fgetc(file);
		if (b == EOF)
			LOG_FATAL("Colormap file \"%s\" is corrupted", path);

		colorinfo.colormap[i] = b;
	}

	fclose(file);
}

uint8_t color_shade(uint8_t color, float shade) {
	assert(colorinfo.colormap != NULL);

	return colorinfo.colormap[(int)(floor(shade * (SHADES - 1)) * COLORS + color)];
}

static int rgb_diff(int r1, int g1, int b1, int r2, int g2, int b2) {
	int r = r2 - r1;
	int g = g2 - g1;
	int b = b2 - b1;
	return r * r + g * g + b * b;
}

uint8_t color_find_closest_to_rgb(int r, int g, int b) {
	int color = 0, min_diff = -1;
	/* COLORS -1 because we are skipping the last color which is used for transparency */
	for (int i = 0; i < COLORS - 1; ++ i) {
		int r2, g2, b2;
		abgr32_to_rgb(colorinfo.pal[i], &r2, &g2, &b2);

		int diff = rgb_diff(r, g, b, r2, g2, b2);
		if (min_diff == -1 || diff < min_diff) {
			min_diff = diff;
			color    = i;
		}
	}
	return color;
}

canvas_t *canvas_new(int w, int h) {
	canvas_t *this = NEW(canvas_t);
	this->w    = w;
	this->h    = h;
	this->size = this->w * this->h;
	this->buf  = (uint8_t*)xalloc(this->size);
	canvas_viewport(this, NULL);
	canvas_clear(this);
	return this;
}

void canvas_destroy(canvas_t *this) {
	xfree(this->buf);
	xfree(this);
}

void canvas_resize(canvas_t *this, int w, int h) {
	xfree(this->buf);

	this->w    = w;
	this->h    = h;
	this->size = this->w * this->h;
	this->buf  = (uint8_t*)xalloc(this->size);
	canvas_viewport(this, NULL);
	canvas_clear(this);
}

canvas_t *canvas_load_lmp(const char *path) {
	FILE *file = fopen(path, "rb");
	if (file == NULL)
		LOG_FATAL("Failed to load LMP file \"%s\"", path);

	uint32_t w, h;
	if (file_read_u32(file, &w) != 0) LOG_FATAL("LMP file \"%s\" is corrupted", path);
	if (file_read_u32(file, &h) != 0) LOG_FATAL("LMP file \"%s\" is corrupted", path);

	canvas_t *this = canvas_new(w, h);
	for (int i = 0; i < this->size; ++ i) {
		int b = fgetc(file);
		if (b == EOF)
			LOG_FATAL("LMP file \"%s\" is corrupted", path);

		this->buf[i] = b;
	}

	fclose(file);
	return this;
}

static void file_write_u32(FILE *file, uint32_t u32) {
	uint8_t bytes[4] = {
		(u32 & 0x000000FF),
		(u32 & 0x0000FF00) >> 8,
		(u32 & 0x00FF0000) >> 16,
		(u32 & 0xFF000000) >> 24,
	};

	for (int i = 0; i < 4; ++ i)
		fputc(bytes[i], file);
}

void canvas_save_lmp(canvas_t *this, const char *path) {
	FILE *file = fopen(path, "wb");
	if (file == NULL)
		LOG_FATAL("Failed to write LMP file \"%s\"", path);

	file_write_u32(file, this->w);
	file_write_u32(file, this->h);

	for (int i = 0; i < this->size; ++ i)
		fputc(this->buf[i], file);

	fclose(file);
}

void canvas_viewport(canvas_t *this, rect_t *rect) {
	if (rect == NULL) {
		this->x1 = 0;
		this->y1 = 0;
		this->x2 = this->w;
		this->y2 = this->h;
	} else {
		this->x1 = rect->x;
		this->y1 = rect->y;

		if (this->x1 < 0) this->x1 = 0;
		if (this->y1 < 0) this->y1 = 0;
		if (this->x1 >= this->w) this->x1 = this->w - 1;
		if (this->y1 >= this->h) this->y1 = this->h - 1;

		this->x2 = rect->x + rect->w;
		this->y2 = rect->y + rect->h;

		if (this->x2 < 0) this->x2 = 0;
		if (this->y2 < 0) this->y2 = 0;
		if (this->x2 >= this->w) this->x2 = this->w - 1;
		if (this->y2 >= this->h) this->y2 = this->h - 1;
	}
}

void canvas_fill(canvas_t *this, uint8_t color) {
	for (int i = 0; i < this->size; ++ i)
		this->buf[i] = color;
}

void canvas_clear(canvas_t *this) {
	memset(this->buf, 0, this->size);
}

uint8_t *canvas_at(canvas_t *this, int x, int y) {
	if (x < this->x1 || x >= this->x2 || y < this->y1 || y >= this->y2)
		return NULL;

	return this->buf + (y * this->w + x);
}

#define FIND_RECT(C, RECT) ((RECT) == NULL? rect_new((C)->x1, (C)->y1, (C)->x2, (C)->y2) : *(RECT))

void canvas_rect_fill(canvas_t *this, rect_t *rect, uint8_t color) {
	rect_t xrect = FIND_RECT(this, rect);

	for (int y = xrect.y; y < xrect.y + xrect.h; ++ y) {
		if (y < this->y1)
			continue;
		if (y >= this->y2)
			break;

		int pos = y * this->w;
		for (int x = xrect.x; x < xrect.x + xrect.w; ++ x) {
			if (x < this->x1)
				continue;
			if (x >= this->x2)
				break;

			this->buf[pos + x] = color;
		}
	}
}

void canvas_rect_outline(canvas_t *this, rect_t *rect, uint8_t color) {
	rect_t xrect = FIND_RECT(this, rect);

	for (int y = 1; y < xrect.h - 1; ++ y) {
		int pos_y = y + xrect.y;
		if (pos_y < this->y1)
			continue;
		if (pos_y >= this->y2)
			break;

		int pos = (pos_y) * this->w + xrect.x;
		if (xrect.x >= this->x1 && xrect.x < this->x2)
			this->buf[pos] = color;

		int pos_x = xrect.x + xrect.w - 1;
		if (pos_x >= this->x1 && pos_x < this->x2)
			this->buf[pos + xrect.w - 1] = color;
	}

	for (int x = 0; x < xrect.w; ++ x) {
		int pos_x = x + xrect.x;
		if (pos_x < this->x1)
			continue;
		if (pos_x >= this->x2)
			break;

		if (xrect.y >= this->y1 && xrect.y < this->y2)
			this->buf[xrect.y * this->w + pos_x] = color;

		int pos_y = xrect.y + xrect.h - 1;
		if (pos_y >= this->y1 && pos_y < this->y2)
			this->buf[pos_y * this->w + pos_x] = color;
	}
}

void canvas_rect_canvas(canvas_t *this, rect_t *rect, canvas_t *canv, rect_t *src) {
	rect_t xrect = FIND_RECT(this, rect);
	rect_t xsrc  = FIND_RECT(canv, src);

	for (int y = 0; y < xrect.h; ++ y) {
		int pos_y = xrect.y + y;
		if (pos_y < this->y1)
			continue;
		else if (pos_y >= this->y2)
			break;

		for (int x = 0; x < xrect.w; ++ x) {
			int pos_x = xrect.x + x;
			if (pos_x < this->x1)
				continue;
			if (pos_x >= this->x2)
				break;

			int src_x = floor((float)x / xrect.w * xsrc.w + xsrc.x);
			int src_y = floor((float)y / xrect.h * xsrc.h + xsrc.y);

			uint8_t color = *canvas_at(canv, src_x, src_y);
			if (color == TRANSPARENT)
				continue;

			*canvas_at(this, pos_x, pos_y) = color;
		}
	}
}

void canvas_rect_dither(canvas_t *this, rect_t *rect, uint8_t color) {
	rect_t xrect = FIND_RECT(this, rect);

	for (int y = xrect.y; y < xrect.y + xrect.h; ++ y) {
		if (y < this->y1)
			continue;
		if (y >= this->y2)
			break;

		int pos = y * this->w;
		for (int x = xrect.x; x < xrect.x + xrect.w; ++ x) {
			bool on = (y + (x % 4 == 0)) % 2 == 0;

			if (x % 2 == 0 && on)
				continue;

			if (x < this->x1)
				continue;
			if (x >= this->x2)
				break;

			this->buf[pos + x] = color;
		}
	}
}

void canvas_line(canvas_t *this, int x1, int y1, int x2, int y2, int n, uint8_t color) {
	bool swap = abs(y2 - y1) > abs(x2 - x1);
	if (swap) {
		SWAP(x1, y1, int);
		SWAP(x2, y2, int);
	}

	if (x1 > x2) {
		SWAP(x1, x2, int);
		SWAP(y1, y2, int);
	}

	float dist_x = x2 - x1;
	float dist_y = abs(y2 - y1);
	float err    = dist_x / 2;
	int   step_y = y1 < y2? 1 : -1;

	bool on = true;
	for (int i = 0; x1 <= x2; ++ i) {
		if (n > 0) {
			if (i % n == 0)
				on = !on;
		}

		if (on) {
			uint8_t *at = swap? canvas_at(this, y1, x1) : canvas_at(this, x1, y1);
			if (at != NULL)
				*at = color;
		}

		err -= dist_y;
		if (err < 0) {
			y1  += step_y;
			err += dist_x;
		}
		++ x1;
	}
}

font_t *font_load_lmp(const char *path, int ch_w, int ch_h) {
	font_t *this = NEW(font_t);
	this->sheet   = canvas_load_lmp(path);
	this->ch_w    = ch_w;
	this->ch_h    = ch_h;
	this->row_len = this->sheet->w / this->ch_w;
	return this;
}

void font_destroy(font_t *this) {
	canvas_destroy(this->sheet);
	xfree(this);
}

int font_render(font_t *this, const char *str, canvas_t *canv,
                int start_x, int start_y, float scale, uint8_t color) {
	int ch_pos_x = start_x;
	int ch_pos_y = start_y;

	for (int i = 0; str[i] != '\0'; ++ i) {
		if (str[i] == '\n') {
			ch_pos_x  = start_x;
			ch_pos_y += (float)this->ch_h * scale + scale;
			continue;
		}

		int sheet_x = str[i] % this->row_len * this->ch_w;
		int sheet_y = str[i] / this->row_len * this->ch_h;

		for (int y = 0; y < (float)this->ch_h * scale; ++ y) {
			int sheet_pos_y = sheet_y + (float)y / scale;

			for (int x = 0; x < (float)this->ch_w * scale; ++ x) {
				int sheet_pos_x = sheet_x + (float)x / scale;

				uint8_t font_color = *canvas_at(this->sheet, sheet_pos_x, sheet_pos_y);
				if (font_color == TRANSPARENT)
					continue;

				uint8_t *at = canvas_at(canv, ch_pos_x + x, ch_pos_y + y);
				if (at != NULL)
					*at = color == TRANSPARENT? font_color : color;
			}
		}

		ch_pos_x += (float)this->ch_w * scale;
	}

	return ch_pos_x - start_x;
}
