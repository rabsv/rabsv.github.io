#ifndef VIDEO_H_HEADER_GUARD
#define VIDEO_H_HEADER_GUARD

#include <SDL2/SDL.h>

#include "common.h"
#include "gfx.h"

typedef struct {
	canvas_t *scr;
	uint32_t *buf;

	float       scale;
	const char *title;
	int w, h, min_w, min_h;

	SDL_Window   *win;
	SDL_Renderer *ren;
	SDL_Texture  *tex;

	bool resizable;
} video_t;

extern video_t video;

typedef struct {
	bool  antialias, fullscr;
	float scale;

	bool resizable;
	int  min_w, min_h;
} video_opts_t;

void video_init(const char *title, int w, int h, video_opts_t opts);
void video_deinit(void);

void video_display(void);
void video_resized(int w, int h);

void video_show_cursor(bool show);

#endif
