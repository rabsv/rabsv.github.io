#ifndef ENGINE_H_HEADER_GUARD
#define ENGINE_H_HEADER_GUARD

#include "common.h"
#include "math.h"
#include "gfx.h"

#define SKY (uint8_t)-1

enum {
	SIDE_DOWN = 0,
	SIDE_UP,
	SIDE_RIGHT,
	SIDE_LEFT,
};

enum {
	SPLIT_NONE = 0,
	SPLIT_HORZ,
	SPLIT_VERT,
};

enum {
	FLOOR = 0,
	WALL,
};

typedef struct {
	uint8_t split;
	float   p1, p2;

	uint8_t type[2];

	/*
	 * SPLIT_HORZ
	 *  _______
	 * |   0   |
	 * |_______|  0 = type[0]
	 * |   1   |  1 = type[1]
	 * |_______|
	 *
	 * SPLIT_VERT
	 *  _______
	 * |   |   |
	 * | 0 | 1 |  0 = type[0]
	 * |   |   |  1 = type[1]
	 * |___|___|
	 *
	 * SPLIT_NONE
	 *  _______
	 * |       |
	 * |   0   |  0 = *type
	 * |       |
	 * |_______|
	 *
	 */

	uint8_t floor_id[2], ceil_id[2], liquid_id, wall_id[5]; /* wall_id[4] = middle */
	float   floor_h[2],  ceil_h[2],  liquid_h;
	float   wall_off[5];

	uint8_t liquid_pal; /* Palette used when under the liquid height */

	float friction;
} tile_t;

uint8_t tile_get_point_split_side(tile_t *tile, float x, float y);
line_t  tile_get_angled_wall_line(tile_t *tile);

typedef struct {
	float x,  y,  z;
	float w,  h,  zh;
	float vx, vy, vz;

	float d, zd, max_speed;

	uint8_t sprite_id;
} entity_t;

entity_t *entity_new(float x, float y, float z, float w, float h, float zh,
                     float d, float max_speed, uint8_t sprite_id);
void entity_destroy(entity_t *this);

void entity_accel     (entity_t *this, float amount, float d);
void entity_accel_forw(entity_t *this, float amount);
void entity_update    (entity_t *this, float friction);

#define ENTITIES_CAP 64

typedef struct {
	canvas_t *canv;
	int tile_size, id_count, row_len;

	struct {
		int  x, y;
		bool waves;
	} *id_data_map;
} sheet_t;

#define SHEET_ID_TO_X(THIS, ID) (THIS)->id_data_map[ID].x
#define SHEET_ID_TO_Y(THIS, ID) (THIS)->id_data_map[ID].y

#define SHEET_ID_HAS_WAVES(THIS, ID) (THIS)->id_data_map[ID].waves

#define SHEET_ID_TO_RECT(THIS, ID) \
	rect_new(SHEET_ID_TO_X(THIS, ID), SHEET_ID_TO_Y(THIS, ID), (THIS)->tile_size, (THIS)->tile_size)

typedef struct {
	size_t  ticks;
	uint8_t next_id;
} anim_t;

typedef struct {
	int     w, h, size;
	tile_t *tiles;

	entity_t *entities[ENTITIES_CAP];
	int       entities_count;
	entity_t *plr;

	sheet_t sheet;
	anim_t *anims;

	canvas_t *sky;
	uint8_t   sky_floor_id;
	float     sky_floor_h;

	float fog_start, fog_end, fog_len;
	float shadow;
	bool  shadow_vert;
} world_t;

void world_init  (world_t *this, const char *sheet_path, int tile_size, const char *sky_path);
void world_deinit(world_t *this);

void world_update(world_t *this, size_t tick);

void world_put_point_in_bounds(world_t *this, float *x, float *y);
bool world_contains(world_t *this, float x, float y);

#define WORLD_AT(THIS, X, Y) ((THIS)->tiles + ((int)(Y) * (THIS)->w + (int)(X)))

typedef struct {
	float x, y, z;
	float d, zd;
} camera_t;

typedef struct {
	/* Info about the tile which ends the sector */
	float   x,      y;
	int     tile_x, tile_y;
	float   dist;
	uint8_t side;
	tile_t *tile;
	uint8_t split_side;
	bool    mid, fog;

	float floor_h, ceil_h, h;
} sector_t; /* An area with the same floor and ceiling height */

#define SECTORS_CAP 16

typedef struct {
	canvas_t *canv;
	world_t  *world;

	camera_t cam;
	float    cam_off, dx, dy;

	float sky_sh;

	float  fov, plane_dist;
	float *x_to_d_map;
	int   *wave_off_map;

	float center_x, center_y;

	float prev_floor_h, prev_ceil_h;

	bool end_at_fog;

	size_t tick;
} scene_t;

#define WAVE_SIZE  0.07
#define WAVE_SPEED 0.05

typedef struct {
	sector_t *sect;

	int   x, start, end, h;
	float d_fix, h_half;
	bool  wall;

	int ceil_end, floor_start;

	int wall1_start, wall1_h;
	int wall2_start, wall2_h;
} column_t;

void scene_setup  (scene_t *this, world_t *world, canvas_t *canv, float fov);
void scene_cleanup(scene_t *this);

void scene_resized   (scene_t *this);
void scene_set_fov   (scene_t *this, float fov);
void scene_set_camera(scene_t *this, camera_t cam);

void scene_render(scene_t *this);

typedef struct {
	float start_x, start_y;
	float dx,      dy;

	int x,       y;
	int step_x,  step_y;

	float len_x,      len_y;
	float len_step_x, len_step_y;

	float dist;
	bool  horz, can_collide, stepped;

	/*
	 * horz        - is the ray currently going horizontal?
	 * can_collide - is the ray in a wall since start?
	 * stepped     - has the ray taken any steps yet?
	 */
} ray_t;

void   ray_init(ray_t *this, float x, float y, float dx, float dy);
void   ray_step(ray_t *this);
line_t ray_get_line_in_tile(ray_t *this);
void   ray_enable_collision(ray_t *this);

#endif
