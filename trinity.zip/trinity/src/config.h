#ifndef CONFIG_H_HEADER_GUARD
#define CONFIG_H_HEADER_GUARD

#define WIN_W 640
#define WIN_H 400

#define FOV       80
#define CAM_SPEED 0.1
#define SENSIT    1

/* TODO: A config JSON file */

#endif
