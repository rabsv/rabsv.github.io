#!/bin/sh

grep -r TODO src/*
