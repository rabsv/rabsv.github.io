#include <stdbool.h> /* bool, true, false */
#include <stdlib.h>  /* exit, EXIT_FAILURE */
#include <string.h>  /* strcmp */

#include <SDL2/SDL.h>
#include <noch/args.h>

#include "config.h"
#include "common.h"
#include "gfx.h"
#include "video.h"
#include "game.h"

#define FPS_CAP 60

const char *argv0;

const char *f_help;
double      f_scale = 1;
bool        f_antialias, f_fullscr;

const char *usages[] = {
	"-h [SUBCOMMAND] | --help [SUBCOMMAND]",
	"<PATH> [OPTIONS]      Run a map file",
	"<SUBCOMMAND> [...]    Run a subcommand",
};

const char *desc = "The trinity 3D raycaster engine\n(https://github.com/lordoftrident/trinity)";

static void usage(FILE *file) {
	args_usage_fprint(file, argv0, usages, ARRAY_LEN(usages), desc, true);

	fprintf(file, "\nSubcommands:\n"
	              "  colormap\n"
	              "  palettize\n"
	              "  viewlmp\n"
	              "\n"
	              "Use \"%s -h <SUBCOMMAND>\" for help about a\n"
	              "specific subcommand\n", argv0);
}

#define SUBCMD_ARGS_CAP 8

typedef struct {
	const char *name, *desc, *usage, *args[SUBCMD_ARGS_CAP];
	void (*run)(const char**);
} subcmd_t;

static void subcmd_colormap (const char **args);
static void subcmd_palettize(const char **args);
static void subcmd_viewlmp  (const char **args);

subcmd_t subcmds[] = {
	{
		.name  = "colormap",
		.desc  = "Create an LMP colormap image file OUT from palette PALETTE",
		.usage = "colormap <OUT> <PALETTE> [OPTIONS]",
		.args  = {"OUT", "PALETTE"},
		.run   = subcmd_colormap,
	},
	{
		.name  = "palettize",
		.desc  = "Turn a BMP image file PATH into LMP image file OUT using palette PALETTE",
		.usage = "palettize <PATH> <OUT> <PALETTE> [OPTIONS]",
		.args  = {"PATH", "OUT", "PALETTE"},
		.run   = subcmd_palettize,
	},
	{
		.name  = "viewlmp",
		.desc  = "View an LMP image file PATH using palette PALETTE",
		.usage = "viewlmp <PATH> <PALETTE> [OPTIONS]",
		.args  = {"PATH", "PALETTE"},
		.run   = subcmd_viewlmp,
	},
};

#define DIE(...) (fprintf(stderr, "Error: " __VA_ARGS__), exit(EXIT_FAILURE))

static void usage_subcmd(FILE *file, const char *name) {
	for (size_t i = 0; i < ARRAY_LEN(subcmds); ++ i) {
		if (strcmp(name, subcmds[i].name) == 0) {
			const char *usages[] = {subcmds[i].usage};
			args_usage_fprint(file, argv0, usages, 1, subcmds[i].desc, false);
			return;
		}
	}

	DIE("Unknown subcommand \"%s\"\n", name);
}

static void parse_flags(args_t *args) {
	size_t where;
	bool   extra;
	if (args_parse_flags(args, &where, NULL, &extra) != 0)
		DIE("\"%s\": %s\n", args->v[where], noch_get_err_msg());
	else if (extra)
		DIE("\"%s\": Unexpected argument\n", args->v[where]);

	if (f_help != NULL) {
		if (*f_help == '\0')
			usage(stdout);
		else
			usage_subcmd(stdout, f_help);

		exit(0);
	}
}

static void run(const char *path) {
	if (f_scale <= 0)
		DIE("Scale expected to be greater than 0, got %f\n", f_scale);

	game_t *e = game_new(path, f_scale, f_antialias, f_fullscr);
	while (!e->quit) {
		game_render(e);
		game_update(e);
	}
	game_destroy(e);
}

static void run_subcmd(subcmd_t *subcmd, args_t *args) {
	if (subcmd == NULL)
		DIE("Unknown subcommand \"%s\"\n", subcmd->name);

	const char *subcmd_args[SUBCMD_ARGS_CAP];
	for (size_t i = 0; i < ARRAY_LEN(subcmd->args) && subcmd->args[i] != NULL; ++ i) {
		const char *arg = args_shift(args);
		if (arg == NULL)
			DIE("Subcommand \"%s\" missing argument \"%s\"\n", subcmd->name, subcmd->args[i]);

		subcmd_args[i] = arg;
	}

	parse_flags(args);
	subcmd->run(subcmd_args);
}

static void parse_subcmd(args_t *args) {
	const char *arg = args_shift(args);

	for (size_t i = 0; i < ARRAY_LEN(subcmds); ++ i) {
		if (strcmp(arg, subcmds[i].name) == 0) {
			run_subcmd(subcmds + i, args);
			return;
		}
	}

	parse_flags(args);
	run(arg);
}

int main(int argc, const char **argv) {
	args_t args = args_new(argc, argv);
	argv0       = args_shift(&args);

	flag_str ("h",  "help",       "Show the usage",  &f_help);
	flag_num (NULL, "scale",      "Window scale",    &f_scale);
	flag_bool(NULL, "antialias",  "Antialiasing",    &f_antialias);
	flag_bool(NULL, "full",       "Fullscreen mode", &f_fullscr);

	set_log_flags(LOG_TIME | LOG_LOCATION);

	if (args.c == 0) {
		usage(stderr);
		fprintf(stderr, "\n======================================================\n");

		DIE("Expected an argument\n");
	}

	if (arg_is_flag(args.v[0])) {
		parse_flags(&args);
		usage(stderr);
		exit(EXIT_FAILURE);
	} else
		parse_subcmd(&args);

	return 0;
}

static void subcmd_colormap(const char **args) {
	const char *out = args[0], *pal = args[1];

	load_palette_bmp(0, pal);

	canvas_t *colormap = canvas_new(COLORS, SHADES);
	for (int x = 0; x < COLORS; ++ x) {
		int r, g, b;
		abgr32_to_rgb(colorinfo.pal[x], &r, &g, &b);

		for (int y = 0; y < SHADES; ++ y) {
			if (x == TRANSPARENT) {
				*canvas_at(colormap, x, y) = TRANSPARENT;
				continue;
			}

			float darken = (float)(SHADES - y) / (SHADES / 2);
			int   r1 = r * darken;
			int   g1 = g * darken;
			int   b1 = b * darken;

			if (r1 > 255) r1 = 255;
			if (g1 > 255) g1 = 255;
			if (b1 > 255) b1 = 255;
			*canvas_at(colormap, x, y) = color_find_closest_to_rgb(r1, g1, b1);
		}
	}

	canvas_save_lmp(colormap, out);
	canvas_destroy(colormap);
	LOG_INFO("Generated colormap \"%s\"", out);

	colorinfo_clean();
}

static void subcmd_palettize(const char **args) {
	const char *path = args[0], *out = args[1], *pal = args[2];

	load_palette_bmp(0, pal);

	SDL_Surface *s = SDL_LoadBMP(path);
	if (s == NULL)
		LOG_FATAL("Failed to load BMP \"%s\"", path);

	canvas_t *canvas = canvas_new(s->w, s->h);
	for (int i = 0; i < canvas->size; ++ i) {
		uint32_t pixel = ((uint32_t*)s->pixels)[i];

		int r = (pixel & s->format->Rmask) >> s->format->Rshift;
		int g = (pixel & s->format->Gmask) >> s->format->Gshift;
		int b = (pixel & s->format->Bmask) >> s->format->Bshift;

		int tr, tg, tb;
		abgr32_to_rgb(colorinfo.pal[TRANSPARENT], &tr, &tg, &tb);

		if (r == tr && g == tg && b == tb)
			canvas->buf[i] = TRANSPARENT;
		else
			canvas->buf[i] = color_find_closest_to_rgb(r, g, b);
	}
	SDL_FreeSurface(s);

	canvas_save_lmp(canvas, out);
	canvas_destroy(canvas);
	LOG_INFO("Palettized \"%s\" into \"%s\"", path, out);

	colorinfo_clean();
}

static void subcmd_viewlmp(const char **args) {
	const char *path = args[0], *pal = args[1];

	canvas_t *canvas = canvas_load_lmp(path);

	if (f_scale <= 0)
		DIE("Scale expected to be greater than 0, got %f\n", f_scale);

	load_palette_bmp(0, pal);

	video_opts_t opts = {
		.scale     = f_scale,
		.antialias = f_antialias,
		.fullscr   = f_fullscr,

		.resizable = true,
		.min_w     = 64,
		.min_h     = 64,
	};
	video_init(path, canvas->w, canvas->h, opts);

	SDL_Event evt;
	bool quit = false;
	do {
		canvas_clear(video.scr);

		rect_t rect = {
			.x = video.scr->w / 2 - canvas->w / 2,
			.y = video.scr->h / 2 - canvas->h / 2,
			.w = canvas->w,
			.h = canvas->h,
		};
		canvas_rect_canvas(video.scr, &rect, canvas, NULL);

		video_display();

		while (SDL_PollEvent(&evt)) {
			switch (evt.type) {
			case SDL_QUIT: quit = true; break;

			case SDL_WINDOWEVENT:
				if (evt.window.event == SDL_WINDOWEVENT_RESIZED)
					video_resized(evt.window.data1, evt.window.data2);
				break;

			default: break;
			}
		}
	} while (!quit);

	video_deinit();
}
